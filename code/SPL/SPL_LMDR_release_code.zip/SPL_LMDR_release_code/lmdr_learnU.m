function U = lmdr_learnU(initU, feat_pairs, labels, T, method)
%U=LMDR_LEARNU()
% initU: a Pxdim matrix
% feat_pairs: a Nxdimx2 matrix
% labels: a Nx1 vector {-1, 1}
% T: the number of iterations
% method: {'Unconstraint', 'Constraint'}. In the 'Constraint' case, we add
% \|U_i\|=1 constraint, which is solved by Augmented Lagerangian method
% From paper: 'Large Margin Dimensionality Reduction for Action Similarity
% Labeling'

% @Author: Xiaojiang Peng. @Email: xiaojiangp@gmail.com. @Date: 27/3/2014

inv_wphi_all_1 = (initU*feat_pairs(:,:,1)')'; 
inv_wphi_all_2 = (initU*feat_pairs(:,:,2)')';
b = mean(sum(bsxfun(@times,inv_wphi_all_1,inv_wphi_all_2),2));

pos_tr_feat = feat_pairs(labels==1,:,:);
neg_tr_feat = feat_pairs(labels==-1,:,:);
nfea = size(feat_pairs,1); 
batch = 10; lamda = 0.1;
U = initU;
switch method
    case 'Unconstraint'
        % objective:  \sum_{i,j} \max{1 - y_ij(\phi'_i x U' x U x \phi_j - b), 0}
        for iter = 1:T
            % balance pos/neg samples
            rnd = floor(rand(1,batch)*nfea/2);
            rnd(find(rnd==0)) = 1; % remove 0 subscript
            if mod(iter,2)==0,     % pos
                feat1 = pos_tr_feat(rnd,:,1); feat2 = pos_tr_feat(rnd,:,2); y_ij = 1;
            else
                feat1 = neg_tr_feat(rnd,:,1); feat2 = neg_tr_feat(rnd,:,2);y_ij = -1;
            end
            wphi_1 = U*feat1'; wphi_2 = U*feat2';
            margins = y_ij.*(sum(bsxfun(@times,wphi_1,wphi_2),1) - b);
            val_wphi_i = wphi_1(:,margins<1);
            % update U
            if size(val_wphi_i,2)>0
                gradU = -2* y_ij* wphi_1(:,margins<1) * feat2(margins<1,:);
                gradb = y_ij;
                U = U - lamda * gradU;
                b = b -lamda * gradb;
            end
        end
        inv_wphi_all_1 = (U*tr_feat_pairs(:,:,1)')'; inv_wphi_all_2 = (U*tr_feat_pairs(:,:,2)')';
        loss = 1 - labels.*(sum(bsxfun(@times,inv_wphi_all_1,inv_wphi_all_2),2)-b);
        loss = sum(loss(loss>0))
    case 'Constraint'
        % Constraint optimization can be transformed to the following unconstrained objective 
        % by Augmented Lagerangian method: 
        % \sum_{i,j} \max{1 - y_ij(\phi'_i x U' x U x \phi_j - b), 0} +
        % 0.5 \mu_t \sum_p (\|U_p\| - 1)^2 - \sum_p \lamda_p (\|U_p\| - 1)
        mu_t = 0.1; delt_mu = 0.01;
        [P, dim] = size(U);
        vec_lamda_p = 0.1 * ones(P, 1);
        for iter = 1:T
            rnd = floor(rand(1,batch)*nfea/2);
            rnd(find(rnd==0)) = 1;
            if mod(iter,2)==0, % pos
                feat1 = pos_tr_feat(rnd,:,1); feat2 = pos_tr_feat(rnd,:,2); y_ij = 1;
            else
                feat1 = neg_tr_feat(rnd,:,1); feat2 = neg_tr_feat(rnd,:,2);y_ij = -1;
            end
            wphi_1 = U*feat1'; wphi_2 = U*feat2';
            margins = y_ij.*(sum(bsxfun(@times,wphi_1,wphi_2),1) - b);
            val_wphi_i = wphi_1(:,margins<1);
            % update U
            gradU_0 = mu_t* bsxfun(@times, ( sqrt(sum(U.^2,2)) - ones(P,1)), U) - ...
                bsxfun(@times,vec_lamda_p,U); 
            if size(val_wphi_i,2)>0
                gradU = -2* y_ij* wphi_1(:,margins<1) * feat2(margins<1,:);
                gradb = y_ij;
                U = U - lamda * (gradU + gradU_0);
                b = b -lamda * gradb;
            else
                U = U - lamda * gradU_0;
            end
            % update \mu and \lamda_p           
            vec_lamda_p = vec_lamda_p - mu_t * ( sqrt(sum(U.^2,2)) - ones(P,1));
            if mu_t>10
               delt_mu = 0.001;
            end
            mu_t = mu_t + delt_mu; 
        end
end