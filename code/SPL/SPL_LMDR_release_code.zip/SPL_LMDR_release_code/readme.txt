Notes:
This folder only includes the key code (lmdr_learnU.m) of my paper "Large Margin Dimensionality Reduction for Action Similarity Labeling".

If you are interesting in the ASLAN task and need the full implementation of my paper, please free to send e-mail me at xiaojiangp@gmail.com.