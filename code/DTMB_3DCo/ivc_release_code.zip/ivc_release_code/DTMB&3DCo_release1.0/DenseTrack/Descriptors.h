#ifndef DESCRIPTORS_H_
#define DESCRIPTORS_H_

#include "DenseTrack.h"

/* get the rectangle for computing the descriptor */
CvScalar getRect(const CvPoint2D32f point, // the interest point position
	const CvSize size, // the size of the image
	const DescInfo descInfo) // parameters about the descriptor
{
	int x_min = descInfo.blockWidth/2;
	int y_min = descInfo.blockHeight/2;
	int x_max = size.width - descInfo.blockWidth;
	int y_max = size.height - descInfo.blockHeight;

	CvPoint2D32f point_temp;

	float temp = point.x - x_min;
	point_temp.x = std::min<float>(std::max<float>(temp, 0.), x_max);

	temp = point.y - y_min;
	point_temp.y = std::min<float>(std::max<float>(temp, 0.), y_max);

	// return the rectangle
	CvScalar rect;
	rect.val[0] = point_temp.x;
	rect.val[1] = point_temp.y;
	rect.val[2] = descInfo.blockWidth;
	rect.val[3] = descInfo.blockHeight;

	return rect;
}

/* compute integral histograms for the whole image */
void BuildDescMat(const IplImage* xComp, // x gradient component
	const IplImage* yComp, // y gradient component
	DescMat* descMat, // output integral histograms
	const DescInfo descInfo) // parameters about the descriptor,CvMat* temp32f
{
	
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.flagThre ? descInfo.nBins-1 : descInfo.nBins;
	// angle stride for quantization
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;	

	int histDim = descMat->nBins;
	int index = 0;
	for(int i = 0; i < height; i++) {
		const float* xcomp = (const float*)(xComp->imageData + xComp->widthStep*i);
		const float* ycomp = (const float*)(yComp->imageData + yComp->widthStep*i);

		// the histogram accumulated in the current line
		std::vector<float> sum(histDim);
		for(int j = 0; j < width; j++, index++) {
			float shiftX = xcomp[j];
			float shiftY = ycomp[j];
			float magnitude0 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude1 = magnitude0;
			float magnitude = magnitude0;
			int bin0, bin1, bin;

			// for the zero bin of hof
			if(descInfo.flagThre == 1 && magnitude0 <= descInfo.threshold) {
				bin0 = nBins; // the zero bin is the last one
				bin = nBins; magnitude = 1.0;
				magnitude0 = 1.0;
				bin1 = 0;
				magnitude1 = 0;
			}
			else {
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;

				// split the magnitude to two adjacent bins
				float fbin = orientation/angleBase;
				bin0 = cvFloor(fbin);
				bin = cvRound(fbin); bin %= nBins;
				float weight0 = 1 - (fbin - bin0);
				float weight1 = 1 - weight0;
				bin0 %= nBins;
				bin1 = (bin0+1)%nBins;

				magnitude0 *= weight0;
				magnitude1 *= weight1;
			}

			sum[bin0] += magnitude0;
			sum[bin1] += magnitude1;
			//sum[bin] += magnitude;
			int temp0 = index*descMat->nBins;
			if(i == 0) { // for the first line
				for(int m = 0; m < descMat->nBins; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*descMat->nBins;
				for(int m = 0; m < descMat->nBins; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
// 			if(temp32f!=NULL)
// 			  temp32f->data.fl[j + i * width] = magnitude;
		}
	}
// 	if(temp32f!=NULL){
// 		IplImage* temp8u = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,1);
// 		cvNormalize(temp32f,temp32f,1,0,CV_MINMAX); 
// 		cvConvertScale(temp32f,temp8u,255,0);
// 		cvShowImage("temp",temp8u);
// 		cvWaitKey(10);
// 		cvReleaseImage(&temp8u);// cvReleaseMat(&temp32f);
// 	}
}

/* get a descriptor from the integral histogram */
std::vector<float> getDesc(const DescMat* descMat, // input integral histogram
	CvScalar rect, // rectangle area for the descriptor
	DescInfo descInfo) // parameters about the descriptor
{
	int descDim = descInfo.dim;
	int height = descMat->height;
	int width = descMat->width;

	boost::numeric::ublas::vector<double> vec(descDim);
	int xOffset = rect.val[0];
	int yOffset = rect.val[1];
	int xStride = rect.val[2]/descInfo.nxCells;
	int yStride = rect.val[3]/descInfo.nyCells;

	// iterate over different cells
	int iDesc = 0;
	for (int iX = 0; iX < descInfo.nxCells; ++iX)
		for (int iY = 0; iY < descInfo.nyCells; ++iY) {
			// get the positions of the rectangle
			int left = xOffset + iX*xStride - 1;
			int right = std::min<int>(left + xStride, width-1);
			int top = yOffset + iY*yStride - 1;
			int bottom = std::min<int>(top + yStride, height-1);

			// get the index in the integral histogram
			int TopLeft = (top*width+left)*descInfo.nBins;
			int TopRight = (top*width+right)*descInfo.nBins;
			int BottomLeft = (bottom*width+left)*descInfo.nBins;
			int BottomRight = (bottom*width+right)*descInfo.nBins;

			for (int i = 0; i < descInfo.nBins; ++i, ++iDesc) {
				double sumTopLeft(0), sumTopRight(0), sumBottomLeft(0), sumBottomRight(0);
				if (top >= 0) {
					if (left >= 0)
						sumTopLeft = descMat->desc[TopLeft+i];
					if (right >= 0)
						sumTopRight = descMat->desc[TopRight+i];
				}
				if (bottom >= 0) {
					if (left >= 0)
						sumBottomLeft = descMat->desc[BottomLeft+i];
					if (right >= 0)
						sumBottomRight = descMat->desc[BottomRight+i];
				}
				float temp = sumBottomRight + sumTopLeft
					- sumBottomLeft - sumTopRight;
				vec[iDesc] = std::max<float>(temp, 0) + epsilon;
			}
		}
		if (descInfo.norm == 1) // L1 normalization
			vec *= 1 / boost::numeric::ublas::norm_1(vec);
		else // L2 normalization
			vec *= 1 / boost::numeric::ublas::norm_2(vec);

		std::vector<float> desc(descDim);
		for (int i = 0; i < descDim; i++)
			desc[i] = vec[i];
		return desc;
}

std::vector<float> getSTCDesc(const STCDescMat* descMat, // input integral histogram
	CvScalar rect,	DescInfo descInfo) 
{
	int nDescBin = descInfo.nBins * descInfo.nBins * descMat->nOffset + descInfo.nBins ;
	int descDim = nDescBin * (descInfo.nxCells*descInfo.nyCells+1);
	int height = descMat->height;
	int width = descMat->width;

	boost::numeric::ublas::vector<double> vec(descDim);
	int xOffset = rect.val[0];
	int yOffset = rect.val[1];
	int xStride = rect.val[2]/descInfo.nxCells;
	int yStride = rect.val[3]/descInfo.nyCells;

	// iterate over different cells
	int iDesc = 0;
	for (int iX = 0; iX < descInfo.nxCells; ++iX)
		for (int iY = 0; iY < descInfo.nyCells; ++iY) {
			// get the positions of the rectangle
			int left = xOffset + iX*xStride - 1;
			int right = std::min<int>(left + xStride, width-1);
			int top = yOffset + iY*yStride - 1;
			int bottom = std::min<int>(top + yStride, height-1);

			// get the index in the integral histogram
			int TopLeft = (top*width+left)*nDescBin;
			int TopRight = (top*width+right)*nDescBin;
			int BottomLeft = (bottom*width+left)*nDescBin;
			int BottomRight = (bottom*width+right)*nDescBin;

			for (int i = 0; i < nDescBin; ++i, ++iDesc) {
				double sumTopLeft(0), sumTopRight(0), sumBottomLeft(0), sumBottomRight(0);
				if (top >= 0) {
					if (left >= 0)
						sumTopLeft = descMat->desc[TopLeft+i];
					if (right >= 0)
						sumTopRight = descMat->desc[TopRight+i];
				}
				if (bottom >= 0) {
					if (left >= 0)
						sumBottomLeft = descMat->desc[BottomLeft+i];
					if (right >= 0)
						sumBottomRight = descMat->desc[BottomRight+i];
				}
				float temp = sumBottomRight + sumTopLeft
					- sumBottomLeft - sumTopRight;
				vec[iDesc] = std::max<float>(temp, 0) + epsilon;
			}
		}
	//---------central rect-----------
		int left = xOffset + 0.5*xStride - 1;
		int right = std::min<int>(left + xStride, width-1);
		int top = yOffset + 0.5*yStride - 1;
		int bottom = std::min<int>(top + yStride, height-1);
		// get the index in the integral histogram
		int TopLeft = (top*width+left)*nDescBin;
		int TopRight = (top*width+right)*nDescBin;
		int BottomLeft = (bottom*width+left)*nDescBin;
		int BottomRight = (bottom*width+right)*nDescBin;

		for (int i = 0; i < nDescBin; ++i, ++iDesc) {
			double sumTopLeft(0), sumTopRight(0), sumBottomLeft(0), sumBottomRight(0);
			if (top >= 0) {
				if (left >= 0)
					sumTopLeft = descMat->desc[TopLeft+i];
				if (right >= 0)
					sumTopRight = descMat->desc[TopRight+i];
			}
			if (bottom >= 0) {
				if (left >= 0)
					sumBottomLeft = descMat->desc[BottomLeft+i];
				if (right >= 0)
					sumBottomRight = descMat->desc[BottomRight+i];
			}
			float temp = sumBottomRight + sumTopLeft
				- sumBottomLeft - sumTopRight;
			vec[iDesc] = std::max<float>(temp, 0) + epsilon;
		}


		if (descInfo.norm == 1) // L1 normalization
			vec *= 1 / boost::numeric::ublas::norm_1(vec);
		else // L2 normalization
			vec *= 1 / boost::numeric::ublas::norm_2(vec);

		std::vector<float> desc(descDim);
		for (int i = 0; i < descDim; i++)
			desc[i] = vec[i];
		return desc;
}

void HogComp(IplImage* img, DescMat* descMat, DescInfo descInfo)
{
	int width = descMat->width;
	int height = descMat->height;
	IplImage* imgX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* imgY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	//CvMat* temp = NULL;,temp
	cvSobel(img, imgX, 1, 0, 1);
	cvSobel(img, imgY, 0, 1, 1);
	BuildDescMat(imgX, imgY, descMat, descInfo);
	cvReleaseImage(&imgX);
	cvReleaseImage(&imgY);

}

void FlowTrackerPoint(IplImage* flow, // the optical field
	CvPoint p_in, // input interest point positions
	CvPoint *p_out, // output interest point positions
	int *status) // status for successfully tracked or not
{
	int width = flow->width;
	int height = flow->height;

	std::list<float> xs;
	std::list<float> ys;
	int x = cvFloor(p_in.x);
	int y = cvFloor(p_in.y);
	// median filtering
	for(int m = x-1; m <= x+1; m++)
		for(int n = y-1; n <= y+1; n++) {
			int p = std::min<int>(std::max<int>(m, 0), width-1);
			int q = std::min<int>(std::max<int>(n, 0), height-1);
			const float* f = (const float*)(flow->imageData + flow->widthStep*q);
			xs.push_back(f[2*p]);
			ys.push_back(f[2*p+1]);
		}
		xs.sort();
		ys.sort();
		int size = xs.size()/2;
		for(int m = 0; m < size; m++) {
			xs.pop_back();
			ys.pop_back();
		}
		CvPoint2D32f offset;
		offset.x = xs.back();
		offset.y = ys.back();		
		p_out->x = cvRound(p_in.x + offset.x);
		p_out->y = cvRound(p_in.y + offset.y);
		if( p_out->x > 0 && p_out->x < width && p_out->y > 0 && p_out->y < height )
			*status = 1;
		else
			*status = -1;

}

void BuildScoHOF(IplImage* xComp, IplImage* yComp, std::vector<CvPoint2D32f> offset, STCDescMat* descMat, DescInfo descInfo)
{
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.flagThre ? descInfo.nBins-1 : descInfo.nBins;
	// angle stride for quantization
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;
	int nOffset = offset.size();
	int histDim = descMat->nBins * descMat->nBins * nOffset;
	int index = 0;//
	for(int i = 0; i < height; i++) {
		//index = index + 2��
		if(i > (height - 3)){// bottom boundary			
			for(int j = 0; j < width; j++, index++) {
				int temp0 = index*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-width)*histDim+m]; 
			}
			continue;
		}

		const float* xcomp1 = (const float*)(xComp->imageData + xComp->widthStep*i);
		const float* ycomp1 = (const float*)(yComp->imageData + yComp->widthStep*i);
		std::vector<float> sum(histDim);
		// the histogram accumulated in the current line
		for(int j = 0; j < width; j++, index++) {
			if(j > (width - 3))// right boundary
			{
				int temp0 = index*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-1)*histDim+m]; 

				continue;
			}
			float shiftX = xcomp1[j];
			float shiftY = ycomp1[j];
			float magnitude00 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude01 = magnitude00;
			float magnitude0 = magnitude00;
			int bin00, bin01, bin0;

			// for the zero bin of hof
			if(descInfo.flagThre == 1 && magnitude00 <= descInfo.threshold) {
				bin0 = nBins;  magnitude0 = 1.0;
				bin00 = nBins; // the zero bin is the last one
				magnitude00 = 1.0;
				bin01 = 0;
				magnitude01 = 0;
			}
			else{
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				float fbin = orientation/angleBase;
				bin00 = cvFloor(fbin);

				float weight00 = 1 - (fbin - bin00);
				float weight01 = 1 - weight00;
				bin00 %= nBins;  bin0 = bin00;
				bin01 = (bin00+1)%nBins;
				magnitude00 *= weight00;
				magnitude01 *= weight01;
			}
			for (int n=0; n<offset.size();n++)
			{
				const float* xcomp2 = (const float*)(xComp->imageData + xComp->widthStep*(i+ (int)offset[n].y));
				const float* ycomp2 = (const float*)(yComp->imageData + yComp->widthStep*(i+ (int)offset[n].y));

				shiftX = xcomp2[j + (int)offset[n].x];
				shiftY = ycomp2[j + (int)offset[n].x];
				float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
				float magnitude11 = magnitude10;
				float magnitude1 = magnitude10;
				int bin10, bin11,bin1;
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				if(descInfo.flagThre == 1 && magnitude10 <= descInfo.threshold) {
					bin1 = nBins; magnitude1 = 1.0;
					bin10 = nBins; // the zero bin is the last one
					magnitude10 = 1.0;
					bin11 = 0;
					magnitude11 = 0;
				}
				else{
					float orientation = cvFastArctan(shiftY, shiftX);
					if(orientation > fullAngle)
						orientation -= fullAngle;
					// split the magnitude to two adjacent bins
					float fbin = orientation/angleBase;
					bin10 = cvFloor(fbin);

					float weight10 = 1 - (fbin - bin10);
					float weight11 = 1 - weight10;
					bin10 %= nBins; bin1 = bin10;
					bin11 = (bin10+1)%nBins;
					magnitude10 *= weight10;
					magnitude11 *= weight11;
				}

  				int sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin10;
  				sum[sub] += 1;//(magnitude1 + magnitude0) / 2;
  				sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin00;
  				sum[sub] += 1;//magnitude0;
				// put into 4 bin sub
//     				int sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin10;
//     				sum[sub] += (magnitude00 + magnitude10)/2;
//     				sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin11;
//     				sum[sub] += (magnitude00 + magnitude11)/2;
//     				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin10;
//     				sum[sub] += (magnitude01 + magnitude10)/2;
//     				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin11;
//     				sum[sub] += (magnitude01 + magnitude11)/2;
//  				// zero offset
//  				sub = n * nBins * nBins + bin00 * nBins + bin00;
//  				sum[sub] += magnitude00;
//  				sub = n * nBins * nBins + bin01 * nBins + bin01;
//  				sum[sub] += magnitude01;
//  				sub = n * nBins * nBins + bin00 * nBins + bin01;
//  				sum[sub] += (magnitude01 + magnitude00)/2;
//  				sub = n * nBins * nBins + bin01 * nBins + bin00;
//  				sum[sub] += (magnitude01 + magnitude00)/2;
			}
			int temp0 = index*histDim;
			if(i == 0) { // for the first line
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
		}		
//  		if (i>40)
//  		{
//  			for(int ii = 0; ii<descInfo.nBins;ii++)
//  			{
//  				for (int j=0; j<descInfo.nBins;j++)
//  				{
//  					std::cout<<sum[ii * descInfo.nBins + j]<<"  ";
//  				}
//  				std::cout<<"\n";
//  			} 		 			
//  			std::cout<<"\n";
//  		}
	}
}
void BuildScoHOG(IplImage* xComp, IplImage* yComp, std::vector<CvPoint2D32f> offset, STCDescMat* descMat, DescInfo descInfo)
{
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.nBins;
	// angle stride for quantization
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;
	int nOffset = offset.size();
	int histDim = descMat->nBins * descMat->nBins * nOffset;
	int index = 0;//
	for(int i = 0; i < height; i++) {
		if(i > (height - 3)){// bottom boundary
			for(int j = 0; j < width; j++, index++) {
				int temp0 = index*histDim;
// 				if(j > (width - 3))// right boundary
// 				{
// 					for(int m = 0; m < histDim; m++)
// 						descMat->desc[temp0++] = descMat->desc[(index-1)*histDim+m]; 
// 				}
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-width)*histDim+m]; 
			}
			continue;
		}

		const float* xcomp1 = (const float*)(xComp->imageData + xComp->widthStep*i);
		const float* ycomp1 = (const float*)(yComp->imageData + yComp->widthStep*i);

		// the histogram accumulated in the current line
		std::vector<float> sum(histDim);
		for(int j = 0; j < width; j++, index++) {
			if(j > (width - 3))// right boundary
			{
				int temp0 = index*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-1)*histDim+m]; 

				continue;
			}
			float shiftX = xcomp1[j];
			float shiftY = ycomp1[j];
			float magnitude00 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude01 = magnitude00;
			float magnitude0 = magnitude00;
			int bin00, bin01, bin0;
			float orientation = cvFastArctan(shiftY, shiftX);
			if(orientation > fullAngle)
				orientation -= fullAngle;
			// split the magnitude to two adjacent bins
			float fbin = orientation/angleBase;
			bin00 = cvFloor(fbin);
			float weight00 = 1 - (fbin - bin00);
			float weight01 = 1 - weight00;
			bin00 %= nBins; bin0 = bin00;
			bin01 = (bin00+1)%nBins;
			magnitude00 *= weight00;
			magnitude01 *= weight01;

			for (int n=0; n<offset.size();n++)
			{
				const float* xcomp2 = (const float*)(xComp->imageData + xComp->widthStep*(i+ (int)offset[n].y));
				const float* ycomp2 = (const float*)(yComp->imageData + yComp->widthStep*(i+ (int)offset[n].y));

				shiftX = xcomp2[j + (int)offset[n].x];
				shiftY = ycomp2[j + (int)offset[n].x];
				float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
				float magnitude11 = magnitude10;
				float magnitude1 = magnitude10;
				int bin10, bin11,bin1;
				orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				fbin = orientation/angleBase;
				bin10 = cvFloor(fbin);
				float weight10 = 1 - (fbin - bin10);
				float weight11 = 1 - weight10;
				bin10 %= nBins; bin1 = bin10;
				bin11 = (bin10+1)%nBins;
				magnitude10 *= weight10;
				magnitude11 *= weight11;

    				int sub = n * nBins * nBins + bin0*nBins +bin1;
    				sum[sub] += 1;//(magnitude1 + magnitude0) / 2;
 				sub = n * nBins * nBins + bin0*nBins +bin0;
 				sum[sub] += 1;//magnitude0;
				// put into 4 bin sub

//     				int sub = n * nBins * nBins + bin00 * nBins + bin10;
//     				sum[sub] += (magnitude00 + magnitude10)/2;
//     				sub = n * nBins * nBins + bin00 * nBins + bin11;
//     				sum[sub] += (magnitude00 + magnitude11)/2;
//     				sub = n * nBins * nBins + bin01 * nBins + bin10;
//     				sum[sub] += (magnitude01 + magnitude10)/2;
//     				sub = n * nBins * nBins + bin01 * nBins + bin11;
//     				sum[sub] += (magnitude01 + magnitude11)/2;
// 					// zero offset
// 					sub = n * nBins * nBins + bin00 * nBins + bin00;
// 					sum[sub] += magnitude00;
// 					sub = n * nBins * nBins + bin01 * nBins + bin01;
// 					sum[sub] += magnitude01;
// 					sub = n * nBins * nBins + bin00 * nBins + bin01;
// 					sum[sub] += (magnitude01 + magnitude00)/2;
// 					sub = n * nBins * nBins + bin01 * nBins + bin00;
// 					sum[sub] += (magnitude01 + magnitude00)/2;
			}

			int temp0 = index*histDim;
			if(i == 0) { // for the first line
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
		}
	/*	if (i>80)
		{
			for(int ii = 0; ii<descInfo.nBins;ii++)
			{
				for (int j=0; j<descInfo.nBins;j++)
				{
					std::cout<<sum[ii * descInfo.nBins + j]<<"  ";
				}
				std::cout<<"\n";
			} 		 			
			std::cout<<"\n";
		}*/
	}
}

void BuildTcoHOG(IplImage* xComp1, IplImage* yComp1, IplImage* xComp2, IplImage* yComp2, 
	STCDescMat* descMat,DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY)
{
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.nBins;
	// angle stride for quantization
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;
	int histDim = descMat->nBins * descMat->nBins;
	int index = 0;
	for(int i = 0; i < height; i++) {
		const float* xcomp1 = (const float*)(xComp1->imageData + xComp1->widthStep*i);
		const float* ycomp1 = (const float*)(yComp1->imageData + yComp1->widthStep*i);

		// the histogram accumulated in the current line
		std::vector<float> sum(histDim);
		for(int j = 0; j < width; j++, index++) {
			float shiftX = xcomp1[j];
			float shiftY = ycomp1[j];
			float magnitude00 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude01 = magnitude00;
			float magnitude0 = magnitude00;
			int bin00, bin01, bin0;
			float orientation = cvFastArctan(shiftY, shiftX);
			if(orientation > fullAngle)
				orientation -= fullAngle;
			// split the magnitude to two adjacent bins
			float fbin = orientation/angleBase;
			bin00 = cvFloor(fbin);
			
 			float weight00 = 1 - (fbin - bin00);
 			float weight01 = 1 - weight00;
			bin00 %= nBins;  bin0 = bin00;
 			bin01 = (bin00+1)%nBins;
 			magnitude00 *= weight00;
 			magnitude01 *= weight01;

			CvPoint p_out;
			p_out.x = (int)points_mapX->data.fl[j + i * width];
			p_out.y = (int)points_mapY->data.fl[j + i * width];
				const float* xcomp2 = (const float*)(xComp2->imageData + xComp2->widthStep*p_out.y);
				const float* ycomp2 = (const float*)(yComp2->imageData + yComp2->widthStep*p_out.y);
				shiftX = xcomp2[(int)p_out.x];
				shiftY = ycomp2[(int)p_out.x];
				float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
				float magnitude11 = magnitude10;
				float magnitude1 = magnitude10;
				int bin10, bin11,bin1;
				orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				fbin = orientation/angleBase;
				bin10 = cvFloor(fbin);
				
 				float weight10 = 1 - (fbin - bin10);
 				float weight11 = 1 - weight10;
				bin10 %= nBins; bin1 = bin10;
 				bin11 = (bin10+1)%nBins;
 				magnitude10 *= weight10;
 				magnitude11 *= weight11;
				// put into 4 bin sub
				//int n = nOffset - 1;
//   				int sub = bin0*nBins +bin1;
//   				sum[sub] += 1;//(magnitude1 + magnitude0) / 2;
				int sub =bin00 * nBins + bin10;
				sum[sub] += (magnitude00 + magnitude10)/2;
				sub = bin00 * nBins + bin11;
				sum[sub] += (magnitude00 + magnitude11)/2;
				sub = bin01 * nBins + bin10;
				sum[sub] += (magnitude01 + magnitude10)/2;
				sub = bin01 * nBins + bin11;
				sum[sub] += (magnitude01 + magnitude11)/2;
			//}			
			//int offsetHist = (nOffset - 1) * nBins * nBins;
			int temp0 = index*histDim;//+ offsetHist;
			if(i == 0) { // for the first line
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*histDim;// + offsetHist;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
		}
//  		if (i>40)
//  		{
//  			for(int ii = 0; ii<descInfo.nBins;ii++)
//  			{
//  				for (int j=0; j<descInfo.nBins;j++)
//  				{
//  					std::cout<<sum[ii * descInfo.nBins + j]<<"  ";
//  				}
//  				std::cout<<"\n";
//  			} 		 			
//  			std::cout<<"\n";
//  		}
	}
}
void getPixelMap(IplImage* flow0, CvMat* points_mapX,CvMat* points_mapY,CvMat* _mapstate)
{
	int ii,jj;
	int width = flow0->width;
	int height = flow0->height;
	for(int i = 0; i < height; i++) 
		for(int j = 0; j < width; j++)
		{	
			CvPoint points_out,points_out2;
			int status = 0;
			FlowTrackerPoint(flow0, cvPoint(j,i), &points_out, &status);
			CV_MAT_ELEM(*_mapstate,float,i,j) = status;
			if (status!=1)
			{
				CV_MAT_ELEM(*points_mapX, float, i, j ) = j;
				CV_MAT_ELEM(*points_mapY, float, i, j ) = i;
			}			
			else
			{
				CV_MAT_ELEM(*points_mapX, float, i, j )  = points_out.x;
				CV_MAT_ELEM(*points_mapY, float, i, j ) = points_out.y;
			}		
		}

}
void getGapPixelMap(CvMat* mapX0,CvMat* mapY0,CvMat* mapX1,CvMat* mapY1, CvMat* points_mapX,CvMat* points_mapY)
{
	int ii,jj;
 	int width = mapX0->cols;
 	int height = mapX0->rows;
	for(int i = 0; i < height; i++) 
		for(int j = 0; j < width; j++)
		{	
			
			ii = (int)CV_MAT_ELEM(*mapY0, float, i, j );//mapY0->data.fl[j + i * width]; 
			jj = (int)CV_MAT_ELEM(*mapX0, float, i, j );//mapX0->data.fl[j + i * width];
			CV_MAT_ELEM(*points_mapX, float, i, j ) = CV_MAT_ELEM(*mapX1, float, ii, jj );
			CV_MAT_ELEM(*points_mapY, float, i, j ) = CV_MAT_ELEM(*mapY1, float, ii, jj );;
// 			points_mapX->data.fl[j + i * width] = mapX1->data.fl[jj + ii * width];
// 			points_mapY->data.fl[j + i * width] = mapY1->data.fl[jj + ii * width];
		}

}
void getPixelMap2(IplImage* flow0,IplImage* flow1,CvMat* points_mapX,CvMat* points_mapY)
{
	int ii,jj;
	int width = flow0->width;
	int height = flow0->height;
	for(int i = 0; i < height; i++) 
		for(int j = 0; j < width; j++)
		{	
// 			ii = (int) flow0->imageData[2*j + i*flow0->widthStep] + i;
// 			jj = (int) flow0->imageData[2*j + 1 + i*flow0->widthStep] + j;
// 			ii = ii<0?i:ii; ii = ii<height?ii:i;
// 			jj = jj<0?j:jj; jj = jj<width?jj:j;
// 			int x = (int) flow1->imageData[2*jj + ii*flow1->widthStep] + jj;
// 			int y = (int) flow1->imageData[2*jj+1 + ii*flow1->widthStep] + ii;
// 			x = x<0?jj:x; x = x<width?x:jj;
// 			y = y<0?ii:y; y = y<height?y:ii;
// 			points_mapX->data.fl[j + i * width] = x;
// 			points_mapY->data.fl[j + i * width] = y;

			CvPoint points_out,points_out2;
			int status = 0;
			FlowTrackerPoint(flow0, cvPoint(j,i), &points_out, &status);
			if (status!=1)
			{
				 points_out.x = j;
				 points_out.y = i;
			}
			status = 0;
			FlowTrackerPoint(flow1, points_out, &points_out2, &status);
			if (status==1)
			{
				points_mapX->data.fl[j + i * width] = points_out2.x;
				points_mapY->data.fl[j + i * width] = points_out2.y;
			}
			else
			{
				points_mapX->data.fl[j + i * width] = points_out.x;
				points_mapY->data.fl[j + i * width] = points_out.y;
			}		
		}

}
void BuildTcoHOF(IplImage* xComp1, IplImage* yComp1, IplImage* xComp2, IplImage* yComp2, 
	 STCDescMat* descMat, DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY)
{
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.flagThre ? descInfo.nBins-1 : descInfo.nBins;
	// angle stride for quantization
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;
	int nOffset = 1;
	int histDim = descInfo.nBins * descInfo.nBins * nOffset;
	int index = 0;

	for(int i = 0; i < height; i++) {
		const float* xcomp1 = (const float*)(xComp1->imageData + xComp1->widthStep*i);
		const float* ycomp1 = (const float*)(yComp1->imageData + yComp1->widthStep*i);

		// the histogram accumulated in the current line
		std::vector<float> sum(histDim);
		for(int j = 0; j < width; j++, index++) {
			float shiftX = xcomp1[j];
			float shiftY = ycomp1[j];
			float magnitude00 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude01 = magnitude00;
			float magnitude0 = magnitude00;
			int bin00, bin01, bin0;

			// for the zero bin of hof
			if(descInfo.flagThre == 1 && magnitude00 <= descInfo.threshold) {
				bin0 = nBins;  magnitude0 = 1.0;
				bin00 = nBins; // the zero bin is the last one
				magnitude00 = 1.0;
				bin01 = 0;
				magnitude01 = 0;
			}
			else{
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				float fbin = orientation/angleBase;
				bin00 = cvFloor(fbin);
				
  				float weight00 = 1 - (fbin - bin00);
  				float weight01 = 1 - weight00;
 				bin00 %= nBins;  bin0 = bin00;
  				bin01 = (bin00+1)%nBins;
  				magnitude00 *= weight00;
  				magnitude01 *= weight01;
			}
			
 			CvPoint pMap;
			pMap.x = (int) CV_MAT_ELEM(*points_mapX,float,i,j);//points_mapX->data.fl[j + i*width];
			pMap.y = (int) CV_MAT_ELEM(*points_mapY,float,i,j);//points_mapY->data.fl[j + i*width];
// 			int status = 0;
// 			FlowTrackerPoint(flow, cvPoint(j,i), &points_out, &status);
// 			if (status==1)
// 			{
				const float* xcomp2 = (const float*)(xComp2->imageData + xComp2->widthStep*pMap.y);
				const float* ycomp2 = (const float*)(yComp2->imageData + yComp2->widthStep*pMap.y);
				shiftX = xcomp2[(int)pMap.x];//[j]
				shiftY = ycomp2[(int)pMap.x];//[j]
				float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
				float magnitude11 = magnitude10;
				float magnitude1 = magnitude10;

				int bin10, bin11, bin1;
				if(descInfo.flagThre == 1 && magnitude10 <= descInfo.threshold) {
					bin1 = nBins; magnitude1 = 1.0;
					bin10 = nBins; // the zero bin is the last one
					magnitude10 = 1.0;
					bin11 = 0;
					magnitude11 = 0;
				}
				else{
					float orientation = cvFastArctan(shiftY, shiftX);
					if(orientation > fullAngle)
						orientation -= fullAngle;
					// split the magnitude to two adjacent bins
					float fbin = orientation/angleBase;
					bin10 = cvFloor(fbin);

  					float weight10 = 1 - (fbin - bin10);
  					float weight11 = 1 - weight10;
 					bin10 %= nBins; bin1 = bin10;
  					bin11 = (bin10+1)%nBins;
  					magnitude10 *= weight10;
  					magnitude11 *= weight11;
				}
				// put into 4 bin sub
				int n = nOffset - 1;
//    				int sub = n * descInfo.nBins * descInfo.nBins + bin0 * descInfo.nBins + bin1;
//    				sum[sub] += 1;//(magnitude1 + magnitude0)/2;
  				int sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin10;
    				sum[sub] += (magnitude00 + magnitude10)/2;
    				sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin11;
    				sum[sub] += (magnitude00 + magnitude11)/2;
    				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin10;
    				sum[sub] += (magnitude01 + magnitude10)/2;
    				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin11;
    				sum[sub] += (magnitude01 + magnitude11)/2;
			//}	
			int temp0 = index*histDim;
			if(i == 0) { // for the first line
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
		}
//    		if (i>40)
//    		{
//    			for(int ii = 0; ii<descInfo.nBins;ii++)
//    			{
//    				for (int j=0; j<descInfo.nBins;j++)
//    				{
//    					std::cout<<sum[ii * descInfo.nBins + j]<<"  ";
//    				}
//    				std::cout<<"\n";
//    			}
//    			
//    			std::cout<<"\n";
//    		}
	}
}

void Build3DcoDesc(IplImage* xComp, IplImage* yComp, IplImage* xComp2t, IplImage* yComp2t, 
	STCDescMat* descMat, DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY, std::vector<CvPoint2D32f> offset)
{
	// whether use full orientation or not
	float fullAngle = descInfo.fullOrientation ? 360 : 180;
	// one additional bin for hof
	int nBins = descInfo.flagThre ? descInfo.nBins-1 : descInfo.nBins;
	// angle stride for quantization
	int boundary = offset[0].x+1;
	float angleBase = fullAngle/float(nBins);
	int width = descMat->width;
	int height = descMat->height;
	int nOffset = offset.size() + 1; //1 for temporal
	int histDim = descInfo.nBins * descInfo.nBins * nOffset + descInfo.nBins;
	int index = 0;
	for(int i = 0; i < height; i++) {
		if(i > (height - boundary)){// bottom boundary
			for(int j = 0; j < width; j++, index++) {
				int temp0 = index*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-width)*histDim+m]; 
			}
			continue;
		}

		const float* xcomp1 = (const float*)(xComp->imageData + xComp->widthStep*i);
		const float* ycomp1 = (const float*)(yComp->imageData + yComp->widthStep*i);

		// the histogram accumulated in the current line
		std::vector<float> sum(histDim);
		for(int j = 0; j < width; j++, index++) {
			if(j > (width - boundary))// right boundary
			{
				int temp0 = index*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[(index-1)*histDim+m]; 

				continue;
			}
			float shiftX = xcomp1[j];
			float shiftY = ycomp1[j];
			float magnitude00 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude01 = magnitude00;
			float magnitude0 = magnitude00;
			int bin00, bin01, bin0;

			// for the zero bin of hof
			if(descInfo.flagThre == 1 && magnitude00 <= descInfo.threshold) {
				bin0 = nBins;  magnitude0 = 1.0;
				bin00 = nBins; // the zero bin is the last one
				magnitude00 = 1.0;
				bin01 = 0;
				magnitude01 = 0;
			}
			else{
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				float fbin = orientation/angleBase;
				bin00 = cvFloor(fbin);

				float weight00 = 1 - (fbin - bin00);
				float weight01 = 1 - weight00;
				bin00 %= nBins;  bin0 = bin00;
				bin01 = (bin00+1)%nBins;
				magnitude00 *= weight00;
				magnitude01 *= weight01;
			}
			// self co-occurrence feature
			//sum[bin0] +=1;
 			sum[bin00] += magnitude00;
 			sum[bin01] += magnitude01;

			// co-occurrence in x and y
			for (int n=0; n<offset.size();n++)
			{
				const float* xcomp2 = (const float*)(xComp->imageData + xComp->widthStep*(i+ (int)offset[n].y));
				const float* ycomp2 = (const float*)(yComp->imageData + yComp->widthStep*(i+ (int)offset[n].y));

				shiftX = xcomp2[j + (int)offset[n].x];
				shiftY = ycomp2[j + (int)offset[n].x];
				float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
				float magnitude11 = magnitude10;
				float magnitude1 = magnitude10;
				int bin10, bin11,bin1;

				if(descInfo.flagThre == 1 && magnitude10 <= descInfo.threshold) {
					bin1 = nBins; magnitude1 = 1.0;
					bin10 = nBins; // the zero bin is the last one
					magnitude10 = 1.0;
					bin11 = 0;
					magnitude11 = 0;
				}
				else{
					float orientation = cvFastArctan(shiftY, shiftX);
					if(orientation > fullAngle)
						orientation -= fullAngle;
					// split the magnitude to two adjacent bins
					float fbin = orientation/angleBase;
					bin10 = cvFloor(fbin);

					float weight10 = 1 - (fbin - bin10);
					float weight11 = 1 - weight10;
					bin10 %= nBins; 
					bin1 = bin10;
					bin11 = (bin10+1)%nBins;
					magnitude10 *= weight10;
					magnitude11 *= weight11;
				}

//       			int sub = n * descInfo.nBins * descInfo.nBins + bin0*descInfo.nBins +bin1+ descInfo.nBins;
//       			sum[sub] += 1;//(magnitude1 + magnitude0) / 2;

				// reduce boundary effects
  				int sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin10 + descInfo.nBins; // start from descInfo.nBins index (skip the self co-)
  				sum[sub] += (magnitude00 + magnitude10)/2;
  				sub = n * descInfo.nBins * descInfo.nBins + bin00 * descInfo.nBins + bin11 + descInfo.nBins;
  				sum[sub] += (magnitude00 + magnitude11)/2;
  				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin10 + descInfo.nBins;
  				sum[sub] += (magnitude01 + magnitude10)/2;
  				sub = n * descInfo.nBins * descInfo.nBins + bin01 * descInfo.nBins + bin11 + descInfo.nBins;
  				sum[sub] += (magnitude01 + magnitude11)/2;

			}
			// temporal co-occurrence 
			CvPoint pMap;
			pMap.x = (int) CV_MAT_ELEM(*points_mapX,float,i,j);//points_mapX->data.fl[j + i*width];
			pMap.y = (int) CV_MAT_ELEM(*points_mapY,float,i,j);//points_mapY->data.fl[j + i*width];

			const float* xcomp2t = (const float*)(xComp2t->imageData + xComp2t->widthStep*pMap.y);
			const float* ycomp2t = (const float*)(yComp2t->imageData + yComp2t->widthStep*pMap.y);
			shiftX = xcomp2t[(int)pMap.x];//[j]
			shiftY = ycomp2t[(int)pMap.x];//[j]
			float magnitude10 = sqrt(shiftX*shiftX+shiftY*shiftY);
			float magnitude11 = magnitude10;
			float magnitude1 = magnitude10;

			int bin10, bin11, bin1;
			if(descInfo.flagThre == 1 && magnitude10 <= descInfo.threshold) {
				bin1 = nBins; magnitude1 = 1.0;
				bin10 = nBins; // the zero bin is the last one
				magnitude10 = 1.0;
				bin11 = 0;
				magnitude11 = 0;
			}
			else{
				float orientation = cvFastArctan(shiftY, shiftX);
				if(orientation > fullAngle)
					orientation -= fullAngle;
				// split the magnitude to two adjacent bins
				float fbin = orientation/angleBase;
				bin10 = cvFloor(fbin);

				float weight10 = 1 - (fbin - bin10);
				float weight11 = 1 - weight10;
				bin10 %= nBins; bin1 = bin10;
				bin11 = (bin10+1)%nBins;
				magnitude10 *= weight10;
				magnitude11 *= weight11;
			}
			
// 			int sub = offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins + bin0 * descInfo.nBins + bin1;
// 			sum[sub] += 1;//(magnitude1 + magnitude0)/2;
 			int sub = offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins + bin00 * descInfo.nBins + bin10;
 			sum[sub] += (magnitude00 + magnitude10)/2;
 			sub = offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins + bin00 * descInfo.nBins + bin11;
 			sum[sub] += (magnitude00 + magnitude11)/2;
 			sub = offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins + bin01 * descInfo.nBins + bin10;
 			sum[sub] += (magnitude01 + magnitude10)/2;
 			sub = offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins + bin01 * descInfo.nBins + bin11;
 			sum[sub] += (magnitude01 + magnitude11)/2;
		
			int temp0 = index*histDim;
			if(i == 0) { // for the first line + offset.size() * descInfo.nBins * descInfo.nBins + descInfo.nBins * descInfo.nBins
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = sum[m];
			}
			else {
				int temp1 = (index - width)*histDim;
				for(int m = 0; m < histDim; m++)
					descMat->desc[temp0++] = descMat->desc[temp1++]+sum[m];
			}
		}
	}
}
void Co3DHoGComp(IplImage* img, IplImage* img2, STCDescMat* descMat,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY, std::vector<CvPoint2D32f> offset)
{
	// compute gradient
	int width = descMat->width;
	int height = descMat->height;
	IplImage* img1X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img1Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img2X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img2Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	cvSobel(img, img1X, 1, 0, 1);
	cvSobel(img, img1Y, 0, 1, 1);	
	cvSobel(img, img2X, 1, 0, 1);
	cvSobel(img, img2Y, 0, 1, 1);
	Build3DcoDesc(img1X, img1Y, img2X, img2Y, descMat, descInfo,points_mapX,points_mapY,offset);
	cvReleaseImage(&img1X);
	cvReleaseImage(&img1Y);
	cvReleaseImage(&img2X);
	cvReleaseImage(&img2Y);
}
void Co3DHoFComp(IplImage* flow0, IplImage* flow1, STCDescMat* descMat,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY, std::vector<CvPoint2D32f> offset)
{
	int width = descMat->width;
	int height = descMat->height;
	IplImage* xComp0 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp0 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* xComp1 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp1 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	// dividing flow to 2 comp
	for(int i = 0; i < height; i++) {
		const float* f0 = (const float*)(flow0->imageData + flow0->widthStep*i);
		float* xf0 = (float*)(xComp0->imageData + xComp0->widthStep*i);
		float* yf0 = (float*)(yComp0->imageData + yComp0->widthStep*i);
		const float* f1 = (const float*)(flow1->imageData + flow1->widthStep*i);
		float* xf1 = (float*)(xComp1->imageData + xComp1->widthStep*i);
		float* yf1 = (float*)(yComp1->imageData + yComp1->widthStep*i);
		for(int j = 0; j < width; j++) {
			xf0[j] = f0[2*j];
			yf0[j] = f0[2*j+1];
			xf1[j] = f1[2*j];
			yf1[j] = f1[2*j+1];
		}
	}
	Build3DcoDesc(xComp0, yComp0, xComp1, yComp1, descMat, descInfo,points_mapX,points_mapY,offset);
	cvReleaseImage(&xComp0);
	cvReleaseImage(&yComp0);
	cvReleaseImage(&xComp1);
	cvReleaseImage(&yComp1);
}
void Co3DMBHComp(IplImage* flow0, IplImage* flow1, STCDescMat* descMatX,STCDescMat* descMatY,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY, std::vector<CvPoint2D32f> offset)
{
	int width = descMatX->width;
	int height = descMatX->height;
	IplImage* flow0X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0XdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0XdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0YdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0YdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1XdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1XdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1YdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1YdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);

	// extract the x and y components of the flow
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow0->imageData + flow0->widthStep*i);
		float* fX = (float*)(flow0X->imageData + flow0X->widthStep*i);
		float* fY = (float*)(flow0Y->imageData + flow0Y->widthStep*i);

		const float* f1 = (const float*)(flow1->imageData + flow1->widthStep*i);
		float* fX1 = (float*)(flow1X->imageData + flow1X->widthStep*i);
		float* fY1 = (float*)(flow1Y->imageData + flow1Y->widthStep*i);

		for(int j = 0; j < width; j++) {
			fX[j] = 100*f[2*j];
			fY[j] = 100*f[2*j+1];
			fX1[j] = 100*f1[2*j];
			fY1[j] = 100*f1[2*j+1];
		}
	}
	cvSobel(flow0X, flow0XdX, 1, 0, 1);
	cvSobel(flow0X, flow0XdY, 0, 1, 1);
	cvSobel(flow0Y, flow0YdX, 1, 0, 1);
	cvSobel(flow0Y, flow0YdY, 0, 1, 1);
	cvSobel(flow1X, flow1XdX, 1, 0, 1);
	cvSobel(flow1X, flow1XdY, 0, 1, 1);
	cvSobel(flow1Y, flow1YdX, 1, 0, 1);
	cvSobel(flow1Y, flow1YdY, 0, 1, 1);

	Build3DcoDesc(flow0XdX, flow0XdY, flow1XdX, flow1XdY, descMatX, descInfo,points_mapX,points_mapY,offset);
	Build3DcoDesc(flow0YdX, flow0YdY, flow1YdX, flow1YdY, descMatY, descInfo,points_mapX,points_mapY,offset);

	cvReleaseImage(&flow0X);
	cvReleaseImage(&flow0Y);
	cvReleaseImage(&flow0XdX);
	cvReleaseImage(&flow0XdY);
	cvReleaseImage(&flow0YdX);
	cvReleaseImage(&flow0YdY);
	cvReleaseImage(&flow1X);
	cvReleaseImage(&flow1Y);
	cvReleaseImage(&flow1XdX);
	cvReleaseImage(&flow1XdY);
	cvReleaseImage(&flow1YdX);
	cvReleaseImage(&flow1YdY);
}

void ShofComp(IplImage* flow, STCDescMat* descMat, DescInfo descInfo, std::vector<CvPoint2D32f> offset)
{
	// compute gradient
	int width = descMat->width;
	int height = descMat->height;
	IplImage* xComp_flow = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp_flow = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	//CvMat* temp = NULL;,temp
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
		float* xf = (float*)(xComp_flow->imageData + xComp_flow->widthStep*i);
		float* yf = (float*)(yComp_flow->imageData + yComp_flow->widthStep*i);
		for(int j = 0; j < width; j++) {
			xf[j] = f[2*j];
			yf[j] = f[2*j+1];
		}
	}
	BuildScoHOF(xComp_flow, yComp_flow,offset, descMat, descInfo);
	cvReleaseImage(&xComp_flow);
	cvReleaseImage(&yComp_flow);
}
void SmbhComp(IplImage* flow, STCDescMat* descMatX,STCDescMat* descMatY, DescInfo descInfo, std::vector<CvPoint2D32f> offset)
{
	// compute gradient
	int width = descMatX->width;
	int height = descMatX->height;
	IplImage* flowX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowXdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowXdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowYdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowYdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);

	int w = flow->width;
	int h = flow->height;
	
	// extract the x and y components of the flow
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
		float* fX = (float*)(flowX->imageData + flowX->widthStep*i);
		float* fY = (float*)(flowY->imageData + flowY->widthStep*i);
		for(int j = 0; j < width; j++) {
			fX[j] = 100*f[2*j];
			fY[j] = 100*f[2*j+1];
		}
	}

	cvSobel(flowX, flowXdX, 1, 0, 1);
	cvSobel(flowX, flowXdY, 0, 1, 1);
	cvSobel(flowY, flowYdX, 1, 0, 1);
	cvSobel(flowY, flowYdY, 0, 1, 1);

// 	BuildDescMat(flowXdX, flowXdY, descMatY, descInfo);//,mag0
// 	BuildDescMat(flowYdX, flowYdY, descMatY, descInfo);//,mag1
	BuildScoHOG(flowXdX,flowXdY,offset,descMatX,descInfo);
	BuildScoHOG(flowYdX,flowYdY,offset,descMatY,descInfo);

	cvReleaseImage(&flowX);
	cvReleaseImage(&flowY);
	cvReleaseImage(&flowXdX);
	//cvReleaseImage(&flowXdY);
	cvReleaseImage(&flowYdX);
	cvReleaseImage(&flowYdY);
}
void ShogComp(IplImage* img, STCDescMat* descMat, DescInfo descInfo, std::vector<CvPoint2D32f> offset)
{
	// compute gradient
	int width = descMat->width;
	int height = descMat->height;
	IplImage* img1X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img1Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	cvSobel(img, img1X, 1, 0, 1);
	cvSobel(img, img1Y, 0, 1, 1);
	// build spatial co-occurrence HOG
	BuildScoHOG(img1X,img1Y,offset,descMat,descInfo);
	cvReleaseImage(&img1X);
	cvReleaseImage(&img1Y);
}
void ThogComp(IplImage* img, IplImage* img2 ,STCDescMat* descMat,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY)
{
	// compute gradient
	int width = descMat->width;
	int height = descMat->height;
	IplImage* img1X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img1Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img2X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* img2Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	cvSobel(img, img1X, 1, 0, 1);
	cvSobel(img, img1Y, 0, 1, 1);	
	cvSobel(img, img2X, 1, 0, 1);
	cvSobel(img, img2Y, 0, 1, 1);
	BuildTcoHOG(img1X, img1Y, img2X, img2Y, descMat, descInfo,points_mapX,points_mapY);
	cvReleaseImage(&img1X);
	cvReleaseImage(&img1Y);
	cvReleaseImage(&img2X);
	cvReleaseImage(&img2Y);
}
void ThofComp(IplImage* flow0, IplImage* flow1, STCDescMat* descMat,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY)
{
	int width = descMat->width;
	int height = descMat->height;
	IplImage* xComp0 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp0 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* xComp1 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp1 = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	// dividing flow to 2 comp
	for(int i = 0; i < height; i++) {
		const float* f0 = (const float*)(flow0->imageData + flow0->widthStep*i);
		float* xf0 = (float*)(xComp0->imageData + xComp0->widthStep*i);
		float* yf0 = (float*)(yComp0->imageData + yComp0->widthStep*i);
		const float* f1 = (const float*)(flow1->imageData + flow1->widthStep*i);
		float* xf1 = (float*)(xComp1->imageData + xComp1->widthStep*i);
		float* yf1 = (float*)(yComp1->imageData + yComp1->widthStep*i);
		for(int j = 0; j < width; j++) {
			xf0[j] = f0[2*j];
			yf0[j] = f0[2*j+1];
			xf1[j] = f1[2*j];
			yf1[j] = f1[2*j+1];
		}
	}
	BuildTcoHOF(xComp0, yComp0, xComp1, yComp1, descMat,descInfo,points_mapX,points_mapY);

	cvReleaseImage(&xComp0);
	cvReleaseImage(&yComp0);
	cvReleaseImage(&xComp1);
	cvReleaseImage(&yComp1);
}
void HofComp(IplImage* flow, DescMat* descMat, DescInfo descInfo)
{
	int width = descMat->width;
	int height = descMat->height;
	IplImage* xComp = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	IplImage* yComp = cvCreateImage(cvSize(width, height), IPL_DEPTH_32F, 1);
	//CvMat* temp = NULL;,temp
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
		float* xf = (float*)(xComp->imageData + xComp->widthStep*i);
		float* yf = (float*)(yComp->imageData + yComp->widthStep*i);
		for(int j = 0; j < width; j++) {
			xf[j] = f[2*j];
			yf[j] = f[2*j+1];
		}
	}
	BuildDescMat(xComp, yComp, descMat, descInfo);
	cvReleaseImage(&xComp);
	cvReleaseImage(&yComp);
}
//IplImage* _MBI, 
void MbhComp(IplImage* flow, DescMat* descMatX, DescMat* descMatY, DescInfo descInfo)
{
	int width = descMatX->width;
	int height = descMatX->height;
	IplImage* flowX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowXdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowXdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowYdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flowYdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);

	int w = flow->width;
	int h = flow->height;
// 	CvMat* mag0 = cvCreateMat(h,w,CV_32FC1);
// 	CvMat* mag1 = cvCreateMat(h,w,CV_32FC1);
// 	CvMat* temp32f = cvCreateMat(h,w,CV_32FC1);
	//CvMat* cmpR = cvCreateMat(h,w,CV_8UC1);
// 	if(!_MBI)
// 		_MBI = cvCreateImage(cvSize(w,h),IPL_DEPTH_8U,1);

	// extract the x and y components of the flow
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
		float* fX = (float*)(flowX->imageData + flowX->widthStep*i);
		float* fY = (float*)(flowY->imageData + flowY->widthStep*i);
		for(int j = 0; j < width; j++) {
			fX[j] = 100*f[2*j];
			fY[j] = 100*f[2*j+1];
		}
	}

	cvSobel(flowX, flowXdX, 1, 0, 1);
	cvSobel(flowX, flowXdY, 0, 1, 1);
	cvSobel(flowY, flowYdX, 1, 0, 1);
	cvSobel(flowY, flowYdY, 0, 1, 1);

	BuildDescMat(flowXdX, flowXdY, descMatX, descInfo);//,mag0
	BuildDescMat(flowYdX, flowYdY, descMatY, descInfo);//,mag1

	//cv::compare()
	//cvCmp(mag0,mag1,cmpR,cv::CMP_GT);
//  	for(int i = 0; i < h; i++) {
//  		for(int j = 0; j < w; j++) {
//    			float magnitude0 = mag0->data.fl[j + i * w];
//    			float magnitude1 = mag1->data.fl[j + i * w];
// 			/*if(cmpR->data.ptr[j + i * w]==255)
// 			temp32f->data.fl[j + i * w] = mag0->data.fl[j + i * w];
// 			else
// 				temp32f->data.fl[j + i * w] = mag1->data.fl[j + i * w];*/
//  			temp32f->data.fl[j + i * w] = magnitude0>magnitude1?magnitude0:magnitude1;
//  		}
//  	}
// 
// 
// 	cvNormalize(temp32f,temp32f,1,0,CV_MINMAX); 
// 	cvConvertScale(temp32f,_MBI,255,0);
// 	cvThreshold(_MBI,_MBI,100,255,CV_THRESH_BINARY|CV_THRESH_OTSU);
// 	//if(!notshow)
// 	//{ 		
// 	//	//cvCanny(temp8u,temp8u,100,200,3);CV_THRESH_OTSU
// 	//	cvShowImage("temp",temp8u); cvWaitKey(10);		
// 	//}	
// 	cvReleaseMat(&temp32f); //cvReleaseMat(&cmpR);
// 	cvReleaseMat(&mag1);cvReleaseMat(&mag0);

	cvReleaseImage(&flowX);
	cvReleaseImage(&flowY);
	cvReleaseImage(&flowXdX);
	cvReleaseImage(&flowXdY);
	cvReleaseImage(&flowYdX);
	cvReleaseImage(&flowYdY);
}

void TmbhComp(IplImage* flow0, IplImage* flow1, STCDescMat* descMatX,STCDescMat* descMatY,
	DescInfo descInfo,CvMat* points_mapX,CvMat* points_mapY)
{
	int width = descMatX->width;
	int height = descMatX->height;
	IplImage* flow0X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0XdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0XdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0YdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow0YdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1X = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1Y = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1XdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1XdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1YdX = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);
	IplImage* flow1YdY = cvCreateImage(cvSize(width,height), IPL_DEPTH_32F, 1);

	// extract the x and y components of the flow
	for(int i = 0; i < height; i++) {
		const float* f = (const float*)(flow0->imageData + flow0->widthStep*i);
		float* fX = (float*)(flow0X->imageData + flow0X->widthStep*i);
		float* fY = (float*)(flow0Y->imageData + flow0Y->widthStep*i);

		const float* f1 = (const float*)(flow1->imageData + flow1->widthStep*i);
		float* fX1 = (float*)(flow1X->imageData + flow1X->widthStep*i);
		float* fY1 = (float*)(flow1Y->imageData + flow1Y->widthStep*i);

		for(int j = 0; j < width; j++) {
			fX[j] = 100*f[2*j];
			fY[j] = 100*f[2*j+1];
			fX1[j] = 100*f1[2*j];
			fY1[j] = 100*f1[2*j+1];
		}
	}
	cvSobel(flow0X, flow0XdX, 1, 0, 1);
	cvSobel(flow0X, flow0XdY, 0, 1, 1);
	cvSobel(flow0Y, flow0YdX, 1, 0, 1);
	cvSobel(flow0Y, flow0YdY, 0, 1, 1);
	cvSobel(flow1X, flow1XdX, 1, 0, 1);
	cvSobel(flow1X, flow1XdY, 0, 1, 1);
	cvSobel(flow1Y, flow1YdX, 1, 0, 1);
	cvSobel(flow1Y, flow1YdY, 0, 1, 1);
    BuildTcoHOG(flow0XdX, flow0XdY, flow1XdX, flow1XdY, descMatX,descInfo,points_mapX,points_mapY);
	BuildTcoHOG(flow0YdX, flow0YdY, flow1YdX, flow1YdY, descMatY,descInfo,points_mapX,points_mapY);
	cvReleaseImage(&flow0X);
	cvReleaseImage(&flow0Y);
	cvReleaseImage(&flow0XdX);
	cvReleaseImage(&flow0XdY);
	cvReleaseImage(&flow0YdX);
	cvReleaseImage(&flow0YdY);
	cvReleaseImage(&flow1X);
	cvReleaseImage(&flow1Y);
	cvReleaseImage(&flow1XdX);
	cvReleaseImage(&flow1XdY);
	cvReleaseImage(&flow1YdX);
	cvReleaseImage(&flow1YdY);
}

/* tracking interest points by median filtering in the optical field */
void OpticalFlowTracker(IplImage* flow, // the optical field
	std::vector<CvPoint2D32f>& points_in, // input interest point positions
	std::vector<CvPoint2D32f>& points_out, // output interest point positions
	std::vector<int>& status) // status for successfully tracked or not
{
	if(points_in.size() != points_out.size())
		fprintf(stderr, "the numbers of points don't match!");
	if(points_in.size() != status.size())
		fprintf(stderr, "the number of status doesn't match!");
	int width = flow->width;
	int height = flow->height;

	for(int i = 0; i < points_in.size(); i++) {
		CvPoint2D32f point_in = points_in[i];
		std::list<float> xs;
		std::list<float> ys;
		int x = cvFloor(point_in.x);
		int y = cvFloor(point_in.y);
		// median filtering
		for(int m = x-1; m <= x+1; m++)
			for(int n = y-1; n <= y+1; n++) {
				int p = std::min<int>(std::max<int>(m, 0), width-1);
				int q = std::min<int>(std::max<int>(n, 0), height-1);
				const float* f = (const float*)(flow->imageData + flow->widthStep*q);
				xs.push_back(f[2*p]);
				ys.push_back(f[2*p+1]);
			}

			xs.sort();
			ys.sort();
			int size = xs.size()/2;
			for(int m = 0; m < size; m++) {
				xs.pop_back();
				ys.pop_back();
			}

			CvPoint2D32f offset;
			offset.x = xs.back();
			offset.y = ys.back();
			CvPoint2D32f point_out;
			point_out.x = point_in.x + offset.x;
			point_out.y = point_in.y + offset.y;
			points_out[i] = point_out;
			if( point_out.x > 0 && point_out.x < width && point_out.y > 0 && point_out.y < height )
				status[i] = 1;
			else
				status[i] = -1;
	}
}
void OpticalFlowTracker2(CvMat* points_mapX,CvMat* points_mapY, CvMat* state_map,
	std::vector<CvPoint2D32f>& points_in, // input interest point positions
	std::vector<CvPoint2D32f>& points_out, // output interest point positions
	std::vector<int>& status) // status for successfully tracked or not
{
	if(points_in.size() != points_out.size())
		fprintf(stderr, "the numbers of points don't match!");
	if(points_in.size() != status.size())
		fprintf(stderr, "the number of status doesn't match!");
	
	for(int i = 0; i < points_in.size(); i++) {
		CvPoint2D32f point_in = points_in[i];
		CvPoint2D32f point_out;
 		point_out.x = CV_MAT_ELEM(*points_mapX,float,(int)point_in.y,(int)point_in.x);
 		point_out.y = CV_MAT_ELEM(*points_mapY,float,(int)point_in.y,(int)point_in.x);
 		points_out[i] = point_out;			
 		status[i] = CV_MAT_ELEM(*state_map,float,(int)point_in.y,(int)point_in.x);
	}
}
/* check whether a trajectory is valid or not */
int isValid(std::vector<CvPoint2D32f>& track, float& mean_x, float& mean_y, float& var_x, float& var_y, float& length)
{
	int size = track.size();
	for(int i = 0; i < size; i++) {
		mean_x += track[i].x;
		mean_y += track[i].y;
	}
	mean_x /= size;
	mean_y /= size;

	for(int i = 0; i < size; i++) {
		track[i].x -= mean_x;
		var_x += track[i].x*track[i].x;
		track[i].y -= mean_y;
		var_y += track[i].y*track[i].y;
	}
	var_x /= size;
	var_y /= size;
	var_x = sqrt(var_x);
	var_y = sqrt(var_y);
	// remove static trajectory
	if(var_x < min_var && var_y < min_var)
		return 0;
	// remove random trajectory
	if( var_x > max_var || var_y > max_var )
		return 0;

	for(int i = 1; i < size; i++) {
		float temp_x = track[i].x - track[i-1].x;
		float temp_y = track[i].y - track[i-1].y;
		length += sqrt(temp_x*temp_x+temp_y*temp_y);
		track[i-1].x = temp_x;
		track[i-1].y = temp_y;
	}

	float len_thre = length*0.7;
	for( int i = 0; i < size-1; i++ ) {
		float temp_x = track[i].x;
		float temp_y = track[i].y;
		float temp_dis = sqrt(temp_x*temp_x + temp_y*temp_y);
		if( temp_dis > max_dis && temp_dis > len_thre )
			return 0;
	}

	track.pop_back();
	// normalize the trajectory
	for(int i = 0; i < size-1; i++) {
		track[i].x /= length;
		track[i].y /= length;
	}
	return 1;
}

// /* detect new feature points in the whole image */
// void cvDenseSample(IplImage* grey, IplImage* eig, std::vector<CvPoint2D32f>& points,
// 	const double quality, const double min_distance)
// {
// 	int width = cvFloor(grey->width/min_distance);
// 	int height = cvFloor(grey->height/min_distance);
// 	double maxVal = 0;
// 	cvCornerMinEigenVal(grey, eig, 3, 3);
// 	cvMinMaxLoc(eig, 0, &maxVal, 0, 0, 0);
// 	const double threshold = maxVal*quality;
// 
// 	int offset = cvFloor(min_distance/2);
// 	for(int i = 0; i < height; i++) 
// 		for(int j = 0; j < width; j++) {
// 			int x = cvFloor(j*min_distance+offset);
// 			int y = cvFloor(i*min_distance+offset);
// 			if(CV_IMAGE_ELEM(eig, float, y, x) > threshold) 
// 				points.push_back(cvPoint2D32f(x,y));
// 		}
// }
void cvDenseSample(IplImage* grey, IplImage* eig, IplImage* flow, std::vector<CvPoint2D32f>& points,
	const double quality, const double min_distance)
{
	int width = cvFloor(grey->width/min_distance);
	int height = cvFloor(grey->height/min_distance);
	double maxVal = 0;
	cvCornerMinEigenVal(grey, eig, 3, 3);
	cvMinMaxLoc(eig, 0, &maxVal, 0, 0, 0);
	const double threshold = maxVal*quality;

	int w = flow->width;
	int h = flow->height;
	IplImage* flowX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	IplImage* flowY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	IplImage* flowXdX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	IplImage* flowXdY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	IplImage* flowYdX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	IplImage* flowYdY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
	CvMat* temp32f = cvCreateMat(h,w,CV_32FC1);
	IplImage* temp8u = cvCreateImage(cvSize(w,h),IPL_DEPTH_8U,1);

	// extract the x and y components of the flow
	for(int i = 0; i < h; i++) {
		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
		float* fX = (float*)(flowX->imageData + flowX->widthStep*i);
		float* fY = (float*)(flowY->imageData + flowY->widthStep*i);
		for(int j = 0; j < w; j++) {
			fX[j] = 100*f[2*j];
			fY[j] = 100*f[2*j+1];
		}
	}

	cvSobel(flowX, flowXdX, 1, 0, 1); 	
	cvSobel(flowX, flowXdY, 0, 1, 1);
	cvSobel(flowY, flowYdX, 1, 0, 1);
	cvSobel(flowY, flowYdY, 0, 1, 1);	

	for(int i = 0; i < h; i++) {
		const float* xcomp = (const float*)(flowXdX->imageData + flowXdX->widthStep*i);
		const float* ycomp = (const float*)(flowXdY->imageData + flowXdY->widthStep*i);
		const float* Yxcomp = (const float*)(flowYdX->imageData + flowYdX->widthStep*i);
		const float* Yycomp = (const float*)(flowYdY->imageData + flowYdY->widthStep*i);
		for(int j = 0; j < w; j++) {
			float shiftX = xcomp[j];
			float shiftY = ycomp[j];
			float magnitude0 = sqrt(shiftX*shiftX+shiftY*shiftY);
			shiftX = Yxcomp[j];  shiftY = Yycomp[j];
			float magnitude1 = sqrt(shiftX*shiftX+shiftY*shiftY);

			temp32f->data.fl[j + i * w] = magnitude0>magnitude1?magnitude0:magnitude1;
		}
	}

	cvReleaseImage(&flowX);
	cvReleaseImage(&flowY);
	cvReleaseImage(&flowXdX);
	cvReleaseImage(&flowXdY);
	cvReleaseImage(&flowYdX);
	cvReleaseImage(&flowYdY);

	cvNormalize(temp32f,temp32f,1,0,CV_MINMAX); 
	cvConvertScale(temp32f,temp8u,255,0);
	//cvSaveImage("temp78.bmp",temp8u);cvWaitKey(10);
	cvThreshold(temp8u,temp8u,100,255,CV_THRESH_BINARY|CV_THRESH_OTSU);

	//cvCanny(temp8u,temp8u,100,200,3);CV_THRESH_OTSU_raw
	//cvShowImage("temp2",temp8u); 

	cvReleaseMat(&temp32f);

	int offset = cvFloor(min_distance/2);
	for(int i = 0; i < height; i++) 
		for(int j = 0; j < width; j++) {
			int x = cvFloor(j*min_distance+offset);
			int y = cvFloor(i*min_distance+offset);//
			if(CV_IMAGE_ELEM(eig, float, y, x) > threshold&&temp8u->imageData[x + y*temp8u->widthStep]) 
				points.push_back(cvPoint2D32f(x,y));
		}
		cvReleaseImage(&temp8u);
}

/* detect new feature points in a image without overlapping to previous points _MBI*/
void cvDenseSample(IplImage* grey, IplImage* flow, IplImage* eig, std::vector<CvPoint2D32f>& points_in,
	std::vector<CvPoint2D32f>& points_out, const double quality, const double min_distance,int notshow)
{
	int width = cvFloor(grey->width/min_distance);
	int height = cvFloor(grey->height/min_distance);
	double maxVal = 0;
	cvCornerMinEigenVal(grey, eig, 3, 3);
	cvMinMaxLoc(eig, 0, &maxVal, 0, 0, 0);
	const double threshold = maxVal*quality;

 	int w = flow->width;
 	int h = flow->height;
 	IplImage* flowX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	IplImage* flowY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	IplImage* flowXdX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	IplImage* flowXdY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	IplImage* flowYdX = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	IplImage* flowYdY = cvCreateImage(cvSize(w,h), IPL_DEPTH_32F, 1);
 	CvMat* temp32f = cvCreateMat(h,w,CV_32FC1);
 	IplImage* temp8u = cvCreateImage(cvSize(w,h),IPL_DEPTH_8U,1);
 
 	// extract the x and y components of the flow
 	for(int i = 0; i < h; i++) {
 		const float* f = (const float*)(flow->imageData + flow->widthStep*i);
 		float* fX = (float*)(flowX->imageData + flowX->widthStep*i);
 		float* fY = (float*)(flowY->imageData + flowY->widthStep*i);
 		for(int j = 0; j < w; j++) {
 			fX[j] = 100*f[2*j];
 			fY[j] = 100*f[2*j+1];
 		}
 	}
 
 	cvSobel(flowX, flowXdX, 1, 0, 1); 	
 	cvSobel(flowX, flowXdY, 0, 1, 1);
 	cvSobel(flowY, flowYdX, 1, 0, 1);
 	cvSobel(flowY, flowYdY, 0, 1, 1);	
 
 	for(int i = 0; i < h; i++) {
 		const float* xcomp = (const float*)(flowXdX->imageData + flowXdX->widthStep*i);
 		const float* ycomp = (const float*)(flowXdY->imageData + flowXdY->widthStep*i);
 		const float* Yxcomp = (const float*)(flowYdX->imageData + flowYdX->widthStep*i);
 		const float* Yycomp = (const float*)(flowYdY->imageData + flowYdY->widthStep*i);
 		for(int j = 0; j < w; j++) {
 			float shiftX = xcomp[j];
 			float shiftY = ycomp[j];
 			float magnitude0 = sqrt(shiftX*shiftX+shiftY*shiftY);
 			shiftX = Yxcomp[j];  shiftY = Yycomp[j];
 			float magnitude1 = sqrt(shiftX*shiftX+shiftY*shiftY);
 
 			temp32f->data.fl[j + i * w] = magnitude0>magnitude1?magnitude0:magnitude1;
 		}
 	}
 
 	cvReleaseImage(&flowX);
 	cvReleaseImage(&flowY);
 	cvReleaseImage(&flowXdX);
 	cvReleaseImage(&flowXdY);
 	cvReleaseImage(&flowYdX);
 	cvReleaseImage(&flowYdY);
 
 	cvNormalize(temp32f,temp32f,1,0,CV_MINMAX); 
 	cvConvertScale(temp32f,temp8u,255,0);
 	//cvSaveImage("temp78.bmp",temp8u);cvWaitKey(10);
 	cvThreshold(temp8u,temp8u,100,255,CV_THRESH_BINARY|CV_THRESH_OTSU);
 
 	//cvCanny(temp8u,temp8u,100,200,3);CV_THRESH_OTSU_raw
 	//cvShowImage("temp2",temp8u); 
 
 	cvReleaseMat(&temp32f);

	std::vector<int> counters(width*height);
	for(int i = 0; i < points_in.size(); i++) {
		CvPoint2D32f point = points_in[i];
		if(point.x >= min_distance*width || point.y >= min_distance*height)
			continue;
		int x = cvFloor(point.x/min_distance);
		int y = cvFloor(point.y/min_distance);
		counters[y*width+x]++;
	}

	int index = 0;
	int offset = cvFloor(min_distance/2);
	for(int i = 0; i < height; i++) 
		for(int j = 0; j < width; j++, index++) {
			if(counters[index] == 0) {
				int x = cvFloor(j*min_distance+offset);
				int y = cvFloor(i*min_distance+offset);// _MBI
				if(CV_IMAGE_ELEM(eig, float, y, x) > threshold&&temp8u->imageData[x + y*temp8u->widthStep]) 
					points_out.push_back(cvPoint2D32f(x,y));
			}
		}

		cvReleaseImage(&temp8u);
}

#endif /*DESCRIPTORS_H_*/
