#include <io.h>
#include <iostream>
#include <sys\stat.h>
#include "time.h"
#include "DenseTrack.h"
#include "Descriptors.h"
#include "Initialize.h"

// due to temporal context, here use 3 frame
IplImageWrapper image, prev_image, pre_prev_image, orin_image, grey, prev_grey, pre_prev_grey,orin_grey;
IplImagePyramid grey_pyramid, prev_grey_pyramid, pre_prev_grey_pyramid,orin_pyramid, eig_pyramid;
std::vector<IplImage*> flow2_pyramid; 
std::vector<IplImage*> flow1_pyramid; 
std::vector<CvMat*> pre_mapX;
std::vector<CvMat*> pre_mapY;
 std::vector<CvMat*> mapX; // 
 std::vector<CvMat*> mapY;
  std::vector<CvMat*> pre_map_state;
  std::vector<CvMat*> map_state;
std::vector<IplImage*> images;
CvCapture* capture = 0;
float* fscales = 0; // float scale values
int show_track = 0; // set show_track = 1, if you want to visualize the trajectories
int cnt = 0;
int main( int argc, char** argv )
{
	int frameNum = 0;
	float fframeNum = 0;
	TrackerInfo tracker;
	DescInfo hogInfo;
	DescInfo hofInfo;
	DescInfo mbhInfo;
	int nOffset = 2; // 2 spatial co
	std::vector<CvPoint2D32f> offset;
	CvPoint2D32f p;
	p.x = 2; p.y = 0; offset.push_back(p);// 
	//p.x = 2; p.y = 2; offset.push_back(p);
	p.x = 0; p.y = 2; offset.push_back(p);
	//p.x = -2; p.y = 2; offset.push_back(p);

	char* video = argv[1];
	//char* video = "test.avi"; // 
	arg_parse(argc, argv);

	/*std::cerr << "start_frame: " << start_frame << " end_frame: " << end_frame << " track_length: " << track_length << std::endl;
	std::cerr << "min_distance: " << min_distance << " patch_size: " << patch_size << " nxy_cell: " << nxy_cell << " nt_cell: " << nt_cell << std::endl;*/

	InitTrackerInfo(&tracker, track_length, init_gap);
	InitDescInfo(&hogInfo, 4, 0, 1, patch_size, nxy_cell, nt_cell);
	InitDescInfo(&hofInfo, 5, 1, 1, patch_size, nxy_cell, nt_cell);
	InitDescInfo(&mbhInfo, 4, 0, 1, patch_size, nxy_cell, nt_cell);

	capture = cvCreateFileCapture(video);

	if( !capture ) { 
		printf( "Could not initialize capturing..\n" );
		return -1;
	}
	//char* outfile = "test.bin";///////////////////////

	FILE *fx = fopen(outfile,"wb");
	if( show_track == 1 )
		cvNamedWindow( "DenseTrack", 0 );

	std::vector<std::list<Track> > xyScaleTracks;
	int init_counter = 0; // indicate when to detect new feature points
	double star,finish;
	star=(double)clock();//
	while( true ) {
		IplImage* frame = 0;
		int i, j, c;
		
		// get a new frame
		frame = cvQueryFrame( capture );
		if( !frame ) {
			//printf("break");
			break;
		}
		if( frameNum >= start_frame && frameNum <= end_frame ) {
			if( !image ) {
				// initialize all the buffers
				image = IplImageWrapper( cvGetSize(frame), 8, 3 );
				image->origin = frame->origin;
				prev_image= IplImageWrapper( cvGetSize(frame), 8, 3 );
				prev_image->origin = frame->origin;
				pre_prev_image= IplImageWrapper( cvGetSize(frame), 8, 3 );
				pre_prev_image->origin = frame->origin;
				orin_image= IplImageWrapper( cvGetSize(frame), 8, 3 );
				orin_image->origin = frame->origin;

				grey = IplImageWrapper( cvGetSize(frame), 8, 1 );
				grey_pyramid = IplImagePyramid( cvGetSize(frame), 8, 1, scale_stride );
				prev_grey = IplImageWrapper( cvGetSize(frame), 8, 1 );
				prev_grey_pyramid = IplImagePyramid( cvGetSize(frame), 8, 1, scale_stride );
				pre_prev_grey = IplImageWrapper( cvGetSize(frame), 8, 1 );
				pre_prev_grey_pyramid = IplImagePyramid( cvGetSize(frame), 8, 1, scale_stride );
				orin_grey = IplImageWrapper( cvGetSize(frame), 8, 1 );
				orin_pyramid = IplImagePyramid( cvGetSize(frame), 8, 1, scale_stride );

				eig_pyramid = IplImagePyramid( cvGetSize(frame), 32, 1, scale_stride );

				cvCopy( frame, image, 0 );
				cvCvtColor( image, grey, CV_BGR2GRAY );
				grey_pyramid.rebuild( grey );

				// how many scale we can have
				scale_num = std::min<std::size_t>(scale_num, grey_pyramid.numOfLevels());
				fscales = (float*)cvAlloc(scale_num*sizeof(float));
				xyScaleTracks.resize(scale_num);				
			}

			// build the image pyramid for the current frame
			cvCopy( frame, image, 0 );
			cvCvtColor( image, grey, CV_BGR2GRAY );
			grey_pyramid.rebuild(grey);
			// images.push_back(cvCloneImage(image));
			// 2nd frame, compute prev flow
			if (frameNum==1)
			{
				for( int ixyScale = 0; ixyScale < scale_num; ++ixyScale ) {
					std::list<Track>& tracks = xyScaleTracks[ixyScale];
					fscales[ixyScale] = pow(scale_stride, ixyScale);

					IplImage *prev_grey_temp = 0, *grey_temp = 0;
					std::size_t temp_level = ixyScale;					
					prev_grey_temp = cvCloneImage(prev_grey_pyramid.getImage(temp_level));
					grey_temp = cvCloneImage(grey_pyramid.getImage(temp_level));
					cv::Mat prev_grey_mat = cv::cvarrToMat(prev_grey_temp);
					cv::Mat grey_mat = cv::cvarrToMat(grey_temp);
					IplImage* flow = cvCreateImage(cvGetSize(grey_temp), IPL_DEPTH_32F, 2);
					cv::Mat flow_mat = cv::cvarrToMat(flow);
					cv::calcOpticalFlowFarneback( prev_grey_mat, grey_mat, flow_mat,
						sqrt(2.0)/2.0, 5, 10, 2, 7, 1.5, cv::OPTFLOW_FARNEBACK_GAUSSIAN );

					flow1_pyramid.push_back(cvCloneImage(flow));
					CvMat* mapx_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					CvMat* mapy_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					CvMat* mapstate_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					getPixelMap(flow,mapx_temp,mapy_temp,mapstate_temp);
					pre_mapX.push_back(cvCloneMat(mapx_temp));
					pre_mapY.push_back(cvCloneMat(mapy_temp));
					pre_map_state.push_back(cvCloneMat(mapstate_temp));
					cvReleaseMat(&mapx_temp);
					cvReleaseMat(&mapy_temp);
					cvReleaseMat(&mapstate_temp);
					// find good features at each scale separately
					IplImage *eig_temp = 0;
					grey_temp = cvCloneImage(grey_pyramid.getImage(temp_level));
					eig_temp = cvCloneImage(eig_pyramid.getImage(temp_level));
					std::vector<CvPoint2D32f> points(0);
					cvDenseSample(prev_grey_temp, eig_temp,flow, points, quality, min_distance);

					// save the feature points
					for( i = 0; i < points.size(); i++ ) {
						Track track(tracker.trackLength);
						PointDesc point(hogInfo, hofInfo, mbhInfo, points[i]);
						track.addPointDesc(point);
						tracks.push_back(track);
					}
					
					cvReleaseImage(&flow);
					cvReleaseImage( &grey_temp );
					cvReleaseImage( &eig_temp );
					cvReleaseImage( &prev_grey_temp );
				}
			}
			if (frameNum==2)
			{
				for( int ixyScale = 0; ixyScale < scale_num; ++ixyScale ) {
					std::list<Track>& tracks = xyScaleTracks[ixyScale];
					fscales[ixyScale] = pow(scale_stride, ixyScale);

					IplImage *prev_grey_temp = 0, *grey_temp = 0;
					std::size_t temp_level = ixyScale;					
					prev_grey_temp = cvCloneImage(prev_grey_pyramid.getImage(temp_level));
					grey_temp = cvCloneImage(grey_pyramid.getImage(temp_level));
					cv::Mat prev_grey_mat = cv::cvarrToMat(prev_grey_temp);
					cv::Mat grey_mat = cv::cvarrToMat(grey_temp);
					IplImage* flow = cvCreateImage(cvGetSize(grey_temp), IPL_DEPTH_32F, 2);
					cv::Mat flow_mat = cv::cvarrToMat(flow);
					cv::calcOpticalFlowFarneback( prev_grey_mat, grey_mat, flow_mat,
						sqrt(2.0)/2.0, 5, 10, 2, 7, 1.5, cv::OPTFLOW_FARNEBACK_GAUSSIAN );

					flow2_pyramid.push_back(cvCloneImage(flow));
					CvMat* mapx_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					CvMat* mapy_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					CvMat* mapstate_temp = cvCreateMat(flow->height,flow->width,CV_32FC1);
					getPixelMap(flow,mapx_temp,mapy_temp,mapstate_temp);
					mapX.push_back(cvCloneMat(mapx_temp));
					mapY.push_back(cvCloneMat(mapy_temp));
					map_state.push_back(cvCloneMat(mapstate_temp));
					cvReleaseMat(&mapx_temp);
					cvReleaseMat(&mapy_temp);
					cvReleaseMat(&mapstate_temp);
					cvReleaseImage(&flow);
					cvReleaseImage( &grey_temp );
					cvReleaseImage( &prev_grey_temp );
				}
			}
			if( frameNum > 2 ) {
				init_counter++;
				for( int ixyScale = 0; ixyScale < scale_num; ++ixyScale ) {
					// track feature points in each scale separately
					//std::cout<<ixyScale<<"\n";
					std::vector<CvPoint2D32f> points_in(0);
					std::list<Track>& tracks = xyScaleTracks[ixyScale];
					for (std::list<Track>::iterator iTrack = tracks.begin(); iTrack != tracks.end(); ++iTrack) {
						CvPoint2D32f point = iTrack->pointDescs.back().point;
						points_in.push_back(point); // collect all the feature points
					}
					int count = points_in.size();
					IplImage *prev_grey_temp = 0, *orin_grey_temp = 0,*grey_temp = 0;
					std::size_t temp_level = ixyScale;
					orin_grey_temp = cvCloneImage(orin_pyramid.getImage(temp_level));//����4thʱ�����2nd֡
					prev_grey_temp = cvCloneImage(prev_grey_pyramid.getImage(temp_level));
					grey_temp = cvCloneImage(grey_pyramid.getImage(temp_level));

					cv::Mat orin_grey_mat = cv::cvarrToMat(orin_grey_temp);
					cv::Mat prev_grey_mat = cv::cvarrToMat(prev_grey_temp);
					cv::Mat grey_mat = cv::cvarrToMat(grey_temp);

					std::vector<int> status(count);
					std::vector<CvPoint2D32f> points_out(count);

					// compute the optical flow
					IplImage* flow3 = cvCreateImage(cvGetSize(grey_temp), IPL_DEPTH_32F, 2);
					cv::Mat flow_mat3 = cv::cvarrToMat(flow3);

 					cv::calcOpticalFlowFarneback( prev_grey_mat, grey_mat, flow_mat3,
 						sqrt(2.0)/2.0, 5, 10, 2, 7, 1.5, cv::OPTFLOW_FARNEBACK_GAUSSIAN );

 					int width = grey_temp->width;
 					int height = grey_temp->height;
 					CvMat* mapx_temp = cvCreateMat(flow3->height,flow3->width,CV_32FC1);
 					CvMat* mapy_temp = cvCreateMat(flow3->height,flow3->width,CV_32FC1);
 					CvMat* mapstate_temp = cvCreateMat(flow3->height,flow3->width,CV_32FC1);
 					CvMat* points_mapX = cvCreateMat(height,width,CV_32FC1);
 					CvMat* points_mapY = cvCreateMat(height,width,CV_32FC1);
 					getGapPixelMap(pre_mapX.at(ixyScale), pre_mapY.at(ixyScale),mapX.at(ixyScale),mapY.at(ixyScale),
 						points_mapX,points_mapY);
 
 					getPixelMap(flow3,mapx_temp,mapy_temp,mapstate_temp);
					
					// track feature points by median filtering
					
					OpticalFlowTracker2(pre_mapX.at(ixyScale), pre_mapY.at(ixyScale),pre_map_state.at(ixyScale),points_in, points_out, status);//------
					// -----------------------------------------------------------//
					// compute the integral histograms
					STCDescMat* MatCoHoG_3D = Init3DCoDescMat(height,width,hogInfo.nBins,offset.size()+1);
					STCDescMat* MatCoHoF_3D = Init3DCoDescMat(height,width,hofInfo.nBins,offset.size()+1);
					STCDescMat* MatCoMBHx_3D = Init3DCoDescMat(height,width,mbhInfo.nBins,offset.size()+1);
					STCDescMat* MatCoMBHy_3D = Init3DCoDescMat(height,width,mbhInfo.nBins,offset.size()+1);
 					Co3DHoGComp(orin_grey_temp, prev_grey_temp, MatCoHoG_3D, hogInfo,points_mapX,points_mapY, offset); 
 					Co3DHoFComp(flow1_pyramid.at(ixyScale), flow3, MatCoHoF_3D, hofInfo,points_mapX,points_mapY, offset); // include temporal information points_mapX
					Co3DMBHComp(flow1_pyramid.at(ixyScale), flow3, MatCoMBHx_3D,MatCoMBHy_3D, mbhInfo,points_mapX,points_mapY,offset); 

 					pre_map_state.at(ixyScale) = map_state.at(ixyScale);
 					pre_mapX.at(ixyScale) = mapX.at(ixyScale);
 					pre_mapY.at(ixyScale) = mapY.at(ixyScale);
 					map_state.at(ixyScale) = cvCloneMat(mapstate_temp);
 					mapX.at(ixyScale) = cvCloneMat(mapx_temp);
 					mapY.at(ixyScale) = cvCloneMat(mapy_temp);
 					cvReleaseMat(&mapx_temp);
 					cvReleaseMat(&mapy_temp);
 					cvReleaseMat(&mapstate_temp);

					flow1_pyramid.at(ixyScale) = flow2_pyramid.at(ixyScale);
					flow2_pyramid.at(ixyScale) = cvCloneImage(flow3);/////////////

					i = 0;
					for (std::list<Track>::iterator iTrack = tracks.begin(); iTrack != tracks.end(); ++i) {
						if( status[i] == 1 ) { // if the feature point is successfully tracked
							PointDesc& pointDesc = iTrack->pointDescs.back();
							CvPoint2D32f prev_point = points_in[i];
							// get the descriptors for the feature point
							CvScalar rect = getRect(prev_point, cvSize(width, height), hogInfo);
							pointDesc.CoHOG_3D = getSTCDesc(MatCoHoG_3D,rect,hogInfo);
							pointDesc.CoHOF_3D = getSTCDesc(MatCoHoF_3D,rect,hofInfo);
							pointDesc.CoMBHx_3D = getSTCDesc(MatCoMBHx_3D,rect,mbhInfo);
							pointDesc.CoMBHy_3D = getSTCDesc(MatCoMBHy_3D,rect,mbhInfo);


							PointDesc point(hogInfo, hofInfo, mbhInfo, points_out[i]);
							iTrack->addPointDesc(point);

							// draw this track
 							if( show_track == 1 ) {
 								std::list<PointDesc>& descs = iTrack->pointDescs;
 								std::list<PointDesc>::iterator iDesc = descs.begin();
 								float length = descs.size();
 								CvPoint2D32f point0 = iDesc->point;
 								point0.x *= fscales[ixyScale]; // map the point to first scale
 								point0.y *= fscales[ixyScale];
 
 								float j = 0;
 								for (iDesc++; iDesc != descs.end(); ++iDesc, ++j) {
 									CvPoint2D32f point1 = iDesc->point;
 									point1.x *= fscales[ixyScale];
 									point1.y *= fscales[ixyScale];
 
 									cvLine(image, cvPointFrom32f(point0), cvPointFrom32f(point1),
 										CV_RGB(0,cvFloor(255.0*(j+1.0)/length),0), 2, 8,0);
 									point0 = point1;
 								}
 								cvCircle(image, cvPointFrom32f(point0), 1, CV_RGB(255,0,0), -1, 8,0);
 							}
							++iTrack;
						}
						else // remove the track, if we lose feature point
							iTrack = tracks.erase(iTrack);
					}
					ReleSTCDescMat(MatCoHoG_3D);
					ReleSTCDescMat(MatCoHoF_3D);
					ReleSTCDescMat(MatCoMBHx_3D);
					ReleSTCDescMat(MatCoMBHy_3D);

 					cvReleaseMat(&points_mapX);
 					cvReleaseMat(&points_mapY);
					cvReleaseImage( &orin_grey_temp );
					cvReleaseImage( &prev_grey_temp );
					cvReleaseImage( &grey_temp );
					cvReleaseImage( &flow3);
				}

				for( int ixyScale = 0; ixyScale < scale_num; ++ixyScale ) {
					std::list<Track>& tracks = xyScaleTracks[ixyScale]; // output the features for each scale
					for( std::list<Track>::iterator iTrack = tracks.begin(); iTrack != tracks.end(); ) {
						if( iTrack->pointDescs.size() >= tracker.trackLength+1 ) { // if the trajectory achieves the length we want
							std::vector<CvPoint2D32f> trajectory(tracker.trackLength+1);
							std::list<PointDesc>& descs = iTrack->pointDescs;
							std::list<PointDesc>::iterator iDesc = descs.begin();

							for (int count = 0; count <= tracker.trackLength; ++iDesc, ++count) {
								trajectory[count].x = iDesc->point.x*fscales[ixyScale];
								trajectory[count].y = iDesc->point.y*fscales[ixyScale];
							}
							float mean_x(0), mean_y(0), var_x(0), var_y(0), length(0);
							if( isValid(trajectory, mean_x, mean_y, var_x, var_y, length) == 1 ) {
								cnt++;
								if( show_track == 1 ) {
									std::list<PointDesc>& descs = iTrack->pointDescs;
									std::list<PointDesc>::iterator iDesc = descs.begin();
									float length = descs.size();
									CvPoint2D32f point0 = iDesc->point;
									point0.x *= fscales[ixyScale]; // map the point to first scale
									point0.y *= fscales[ixyScale];

									float j = 0;
									for (iDesc++; iDesc != descs.end(); ++iDesc, ++j) {
										CvPoint2D32f point1 = iDesc->point;
										point1.x *= fscales[ixyScale];
										point1.y *= fscales[ixyScale];
										cvLine(image, cvPointFrom32f(point0), cvPointFrom32f(point1),
											CV_RGB(0,cvFloor(255.0*(j+1.0)/length),0), 1, 8,0);
										point0 = point1;
									}
										cvCircle(image, cvPointFrom32f(point0), 1, CV_RGB(255,0,0), -1, 8,0);

								}

 								fframeNum = (float)frameNum - 2.0;
 								fwrite(&fframeNum,sizeof(float),1,fx);
 								fwrite(&mean_x,sizeof(float),1,fx);
 								fwrite(&mean_y,sizeof(float),1,fx);
 								fwrite(&var_x,sizeof(float),1,fx);
 								fwrite(&var_y,sizeof(float),1,fx);
 								fwrite(&length,sizeof(float),1,fx);
 								fwrite(&fscales[ixyScale],sizeof(float),1,fx);
 								for (int count = 0; count < tracker.trackLength; ++count){
 									fwrite(&trajectory[count].x,sizeof(float),1,fx);
 									fwrite(&trajectory[count].y,sizeof(float),1,fx);
 								}
								// save 3D CoHOG
								iDesc = descs.begin();
								int t_stride = cvFloor(tracker.trackLength/hogInfo.ntCells);
								int dim_CoHOG3D = (hogInfo.nBins * hogInfo.nBins *(offset.size() +1)+ hogInfo.nBins)*5;
								float temp_Vec;
								for( int n = 0; n < hogInfo.ntCells; n++ ) {
									std::vector<float> vec(dim_CoHOG3D);
									for( int t = 0; t < t_stride; t++, iDesc++ )
										for( int m = 0; m < dim_CoHOG3D; m++ )
											vec[m] += iDesc->CoHOG_3D[m];
									for( int m = 0; m < dim_CoHOG3D; m++ ){
										temp_Vec = vec[m]/float(t_stride); // average 
										fwrite(&temp_Vec,sizeof(float),1,fx);
									}
								}
								// save 3D CoHOF
								iDesc = descs.begin();
								int dim_CoHOF3D = (hofInfo.nBins * hofInfo.nBins *(offset.size() +1)+ hofInfo.nBins)*5;							
								for( int n = 0; n < hofInfo.ntCells; n++ ) {
									std::vector<float> vec(dim_CoHOF3D);
									for( int t = 0; t < t_stride; t++, iDesc++ )
										for( int m = 0; m < dim_CoHOF3D; m++ )
											vec[m] += iDesc->CoHOF_3D[m];
									for( int m = 0; m < dim_CoHOF3D; m++ ){
										temp_Vec = vec[m]/float(t_stride); // average 
										fwrite(&temp_Vec,sizeof(float),1,fx);
									}
								}
								// save 3D CoMBHx
								iDesc = descs.begin();
								int dim_CoMBH3D = (mbhInfo.nBins * mbhInfo.nBins *(offset.size() +1)+ mbhInfo.nBins)*5;							
								for( int n = 0; n < mbhInfo.ntCells; n++ ) {
									std::vector<float> vec(dim_CoMBH3D);
									for( int t = 0; t < t_stride; t++, iDesc++ )
										for( int m = 0; m < dim_CoMBH3D; m++ )
											vec[m] += iDesc->CoMBHx_3D[m];
									for( int m = 0; m < dim_CoMBH3D; m++ ){
										temp_Vec = vec[m]/float(t_stride); // average 
										fwrite(&temp_Vec,sizeof(float),1,fx);
									}
								}
								// save 3D CoMBHy
								iDesc = descs.begin();						
								for( int n = 0; n < mbhInfo.ntCells; n++ ) {
									std::vector<float> vec(dim_CoMBH3D);
									for( int t = 0; t < t_stride; t++, iDesc++ )
										for( int m = 0; m < dim_CoMBH3D; m++ )
											vec[m] += iDesc->CoMBHy_3D[m];
									for( int m = 0; m < dim_CoMBH3D; m++ ){
										temp_Vec = vec[m]/float(t_stride); // average 
										fwrite(&temp_Vec,sizeof(float),1,fx);
									}
								}								
							}
							iTrack = tracks.erase(iTrack);
						}
						else
							iTrack++;
					}
				}

				if( init_counter == tracker.initGap ) { // detect new feature points every initGap frames
					init_counter = 0;
					for (int ixyScale = 0; ixyScale < scale_num; ++ixyScale) {
						std::list<Track>& tracks = xyScaleTracks[ixyScale];
						std::vector<CvPoint2D32f> points_in(0);
						std::vector<CvPoint2D32f> points_out(0);
						for(std::list<Track>::iterator iTrack = tracks.begin(); iTrack != tracks.end(); iTrack++, i++) {
							std::list<PointDesc>& descs = iTrack->pointDescs;
							CvPoint2D32f point = descs.back().point; // the last point in the track
							points_in.push_back(point);
						}

						IplImage *pre_prev_grey_temp = 0, *prev_eig_temp = 0;
						std::size_t temp_level = (std::size_t)ixyScale;
						pre_prev_grey_temp = cvCloneImage(pre_prev_grey_pyramid.getImage(temp_level));
						prev_eig_temp = cvCloneImage(eig_pyramid.getImage(temp_level));
						cvDenseSample(pre_prev_grey_temp, flow1_pyramid.at(ixyScale),prev_eig_temp, points_in, 
							points_out, quality, min_distance,ixyScale);
						// save the new feature points
						for( i = 0; i < points_out.size(); i++) {
							Track track(tracker.trackLength);
							PointDesc point(hogInfo, hofInfo, mbhInfo, points_out[i]);
							track.addPointDesc(point);
							tracks.push_back(track);
						}
						cvReleaseImage( &pre_prev_grey_temp );
						cvReleaseImage( &prev_eig_temp );
					}
				}
			}
			//flow_pyramid.clear();
			cvCopy( pre_prev_image, orin_image, 0 );
			cvCvtColor( orin_image, orin_grey, CV_BGR2GRAY );
			orin_pyramid.rebuild(orin_grey);

			cvCopy( prev_image, pre_prev_image, 0 );
			cvCvtColor( pre_prev_image, pre_prev_grey, CV_BGR2GRAY );
			pre_prev_grey_pyramid = prev_grey_pyramid;
			pre_prev_grey_pyramid.rebuild(pre_prev_grey);

			cvCopy( frame, prev_image, 0 );
			cvCvtColor( prev_image, prev_grey, CV_BGR2GRAY );
			prev_grey_pyramid.rebuild(prev_grey);			
		}

		if( show_track == 1 ) {
			cvShowImage( "DenseTrack", image);
			c = cvWaitKey(3);
			if((char)c == 27) break;
		}
		// get the next frame
		frameNum++;
		printf("%d\n",frameNum);
	}
	flow1_pyramid.clear(); flow2_pyramid.clear();
	pre_mapX.clear(); pre_mapY.clear();
	mapX.clear(); mapY.clear();
	pre_map_state.clear(); map_state.clear();
	finish=(double)clock();//
 	float ft = (finish-star)/frameNum;
	std::cout<<ft<<"ms/frame  "<<"run-time: "<<(finish-star)/1000<<"  trajectory #: "<<cnt<<"\n";
	if( show_track == 1 )
		cvDestroyWindow("DenseTrack");
	fclose(fx);
	return 0;
}
