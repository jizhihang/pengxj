Note: This code is based on Wang's release1.1 version (http://lear.inrialpes.fr/people/wang/dense_trajectories).
It contains the source code for 3D Co-occurrence features extraction mentioned in our paper "Motion Boundary Based Sampling and 3D Co-occurrence Descriptors for Action Recognition".

### Compiling ###

In order to compile the dense trajectories code, you need to have the following libraries installed in your system:
* Microsoft Visual Studio (tested with VS 2010)
* OpenCV library (tested with OpenCV-2.4.3)
* boost libraries (tested with boost_1_50)

### Quick start ###

A executable is already in the directory './Release/'. You only need to install opencv (add its dll path to the system path)
and then click file "run.bat".
When you edit this .bat file, you can find the format is "DenseTrack [filename.avi] -o [featureFilename.bin]".

### How to read feature by matlab? ###
A '.m' file named 'xread3DCo_DT_bin.m' is also contained in order to read the 3D Co-occurrence features by matlab. Please first read the source code.
If you have any problems or find any bugs, please free to contact me at xiaojiangp@gmail.com.

Enjoy!