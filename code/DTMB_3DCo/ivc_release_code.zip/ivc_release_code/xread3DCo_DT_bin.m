%% xread3DCo_DT_bin
%  dt.trajectory 3dCoHOG 3dCoHOF 3dCoMBHx 3dCoMBHy
function [feature] = xread3DCo_DT_bin(file,nbin,grids)
%%xread3DCo_DT_bin:
%% demo: feature = xread3DCo_DT_bin(test.bin,4,[5,3]);
%%

nfea = 3577; dim1=780; dim2=1200;

n3dCohog = nbin*nbin*grids(1)*grids(2)*3 + nbin*grids(1)*grids(3); % 
n3dCohof = (nbin+1)*(nbin+1)*grids(1)*grids(2)*3 + (nbin+1)*grids(1)*grids(2);
n3dCombh = n3dCohog;
nfea =37 + n3dCohog + n3dCohof + 2*n3dCombh;

if exist(file, 'file')
    fid = fopen(file,'rb');
    temp = fread(fid, [nfea, inf],'single');
    fclose(fid);
    dt.trajectory = temp(8:37,:)';
    nstar = 38; nend = nstar + n3dCohog -1;
    dt.CoHOG = temp(nstar:nend,:)';
    nstar = nend + 1; nend = nend + n3dCohof;
    dt.CoHOF = temp(nstar:nend,:)';
    nstar = nend + 1; nend = nend + n3dCombh;
    dt.CoMBHx = temp(nstar:nend,:)';
    nstar = nend + 1; nend = nend + n3dCombh;
    dt.CoMBHy = temp(nstar:nend,:)';
else
    fprintf([file, 'invalidate, please check!']);
end