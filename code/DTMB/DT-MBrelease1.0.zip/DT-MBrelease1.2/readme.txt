Note: This code is based on Wang's release1.1 version (http://lear.inrialpes.fr/people/wang/dense_trajectories).
Both regural DT and our DT-MB are included in the codes. The codes are tested under Window7 OS (as many guys wanted...).

### Compiling ###

In order to compile the dense trajectories code, you need to have the following libraries installed in your system:
* Microsoft Visual Studio (tested with VS 2010)
* OpenCV library (tested with OpenCV-2.4.3)
* boost libraries (tested with boost_1_50)

### Quick start ###

A executable is already in the directory './Release/'. You only need to install opencv (add its dll path to the system path)
and then click file "run.bat".
When you edit this .bat file, you can find the format is "DenseTrack [filename.avi] -o [featureFilename.bin] -u [0 or 1]". The option 'u' controls whether to show the trajectories or not.

### How to read feature by matlab? ###
A .m file named 'xread_DT_bin.m' is also contained in order to read dt features by matlab.Please first read the source codes.
If you have any problems or find any bugs, please free to contact me at xiaojiangp@gmail.com. 
Enjoy!
